<?php


session_start();
require_once "..\connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");  // PHP-ban átirányítás
    exit();  // Fontos, hogy leállítsd a további kód futtatását
}




// Felhasználók és hirdetések listájának lekérdezése, akikkel chateltünk
$user_id = $_SESSION['user_id'];
$sql = "SELECT DISTINCT u.user_id, u.username, u.profilepic, a.ad_id, a.title AS ad_title
        FROM users u
        JOIN chat c ON (u.user_id = c.sender_id OR u.user_id = c.receiver_id)
        JOIN ads a ON c.ad_id = a.ad_id
        WHERE (c.sender_id = ? OR c.receiver_id = ?)
        AND u.user_id != ?
        ORDER BY u.username, a.title";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $user_id, $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

$chats = [];
while ($row = $result->fetch_assoc()) {
    $chats[] = $row;
}
?>

<?php require("../head.php"); ?>
<link rel="stylesheet" href="../css/chat.css">

<div class="chat_container">
    <h2>Felhasználók, akikkel chateltél</h2>
    <ul class="chat_user_list">
        <?php foreach ($chats as $chat): ?>
            <li class="chat_user">
                <a href="chat_details.php?user_id=<?php echo $chat['user_id']; ?>&ad_id=<?php echo $chat['ad_id']; ?>" class="chat_link">
                    <div class="chat_user_avatar">
                        <img src="/techbazar/<?php echo !empty($chat['profilepic']) ? htmlspecialchars($chat['profilepic']) : 'default_profiles/nabalint.png'; ?>" alt="Avatar">
                    </div>
                    <div class="chat_user_info">
                        <span class="chat_username"><?php echo htmlspecialchars($chat['username']); ?></span>
                        <span class="chat_ad_title"><?php echo htmlspecialchars($chat['ad_title']); ?></span>
                    </div>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

<!-- Popup Modal -->
<div id="popupModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close-btn" onclick="closePopup()">&times;</span>
        <iframe id="popupFrame" name="popupFrame" src=""></iframe>
    </div>
</div>

<script>
function openPopup(pageUrl) {
    document.getElementById("popupFrame").src = pageUrl;
    document.getElementById("popupModal").style.display = "flex";
}

function closePopup() {
    document.getElementById("popupModal").style.display = "none";
    document.getElementById("popupFrame").src = "";
    setTimeout(() => { location.reload(); }, 50);
}
</script>

<?php require("../footer.php"); ?>
</body>
</html>

<?php
// Adatbázis kapcsolat lezárása
$stmt->close();
$conn->close();
?>