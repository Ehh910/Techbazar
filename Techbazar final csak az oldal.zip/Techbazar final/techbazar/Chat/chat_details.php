<?php


session_start();
require_once "..\connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");  // PHP-ban átirányítás
    exit();  // Fontos, hogy leállítsd a további kód futtatását
}



// Kiválasztott felhasználó és hirdetés adatainak lekérdezése
$selected_user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;
$ad_id = isset($_GET['ad_id']) ? $_GET['ad_id'] : null;

if ($selected_user_id && $ad_id) {
    // Felhasználó nevének lekérdezése
    $sql = "SELECT username FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $selected_user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $selected_user_name = $user['username'];
    } else {
        die("Felhasználó nem található.");
    }

    // Üzenetek lekérdezése
    $sql = "SELECT * FROM chat 
            WHERE ad_id = ? 
            AND ((sender_id = ? AND receiver_id = ?) 
            OR (sender_id = ? AND receiver_id = ?))
            ORDER BY sent_date ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiiii", $ad_id, $_SESSION['user_id'], $selected_user_id, $selected_user_id, $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    $messages = [];
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }

    // Hirdetés adatainak lekérdezése
    $sql = "SELECT title FROM ads WHERE ad_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ad_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $ad = $result->fetch_assoc();
    } else {
        die("Hirdetés nem található.");
    }
}
?>

<?php require("../head.php"); ?>
    <link rel="stylesheet" href="../css/chat_details.css">
    <div class="chat-details">
        <?php if ($selected_user_id && $ad_id): ?>
            <h2>Üzenetek <?php echo htmlspecialchars($selected_user_name); ?> felhasználóval</h2>
            <h3>Hirdetés: <?php echo htmlspecialchars($ad['title']); ?></h3>

            <!-- Image Carousel for Listing -->
            <div class="ad-carousel">
                <div class="image-carousel">
                    <?php
                    // Fetch listing images
                    $image_sql = "SELECT image_url FROM ads_images WHERE ad_id = ?";
                    $image_stmt = $conn->prepare($image_sql);
                    $image_stmt->bind_param("i", $ad_id);
                    $image_stmt->execute();
                    $image_result = $image_stmt->get_result();

                    $images = [];
                    while ($row = $image_result->fetch_assoc()) {
                        $images[] = $row['image_url'];
                    }

                   

                    foreach ($images as $index => $image_url): ?>
                        <img src="../<?php echo htmlspecialchars($image_url); ?>" 
                             class="carousel-image <?php echo $index === 0 ? 'active' : ''; ?>" 
                             alt="Hirdetés kép <?php echo $index + 1; ?>">
                    <?php endforeach; ?>

                    <?php if (count($images) > 1): ?>
                    <div class="carouselbtns">
                        <button class="carousel-button prev" onclick="prevImage()">❮</button>
                        <button class="carousel-button next" onclick="nextImage()">❯</button>
                    </div>
                <?php endif; ?>
                </div>
                
            </div>

            <!-- Messages Section -->
            <div class="messages">
                <?php foreach ($messages as $message): ?>
                    <div class="message <?php echo ($message['sender_id'] == $_SESSION['user_id']) ? 'sent' : 'received'; ?>">
                        <a href="../profile.php?user_id=<?php echo $message['sender_id']; ?>" class="message-username">
                            <?php
                            if ($message['sender_id'] == $_SESSION['user_id']) {
                                echo htmlspecialchars($_SESSION['username']);
                            } else {
                                echo htmlspecialchars($selected_user_name);
                            }
                            ?>
                        </a>
                        <p><?php echo htmlspecialchars($message['message']); ?></p>
                        <span><?php echo $message['sent_date']; ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Message Form -->
            <form action="send_message_handler.php" method="POST" class="message-form">
                <input type="hidden" name="receiver_id" value="<?php echo $selected_user_id; ?>">
                <input type="hidden" name="ad_id" value="<?php echo $ad_id; ?>">
                <textarea name="message" placeholder="Írja be üzenetét..." required></textarea>
                <button type="submit">Üzenet Küldése</button>
            </form>
        <?php else: ?>
            <p>Nincs kiválasztott felhasználó vagy hirdetés.</p>
        <?php endif; ?>
    </div>

    <script>
        let currentImageIndex = 0;
        const images = document.querySelectorAll('.carousel-image');

        function showImage(index) {
            images.forEach((img, i) => {
                img.classList.remove('active');
                if (i === index) {
                    img.classList.add('active');
                }
            });
        }

        function prevImage() {
            currentImageIndex = (currentImageIndex > 0) ? currentImageIndex - 1 : images.length - 1;
            showImage(currentImageIndex);
        }

        function nextImage() {
            currentImageIndex = (currentImageIndex < images.length - 1) ? currentImageIndex + 1 : 0;
            showImage(currentImageIndex);
        }
    </script>
    <?php require("../footer.php"); ?>
</body>
</html>

<?php
// Adatbázis kapcsolat lezárása
$stmt->close();
$conn->close();
?>