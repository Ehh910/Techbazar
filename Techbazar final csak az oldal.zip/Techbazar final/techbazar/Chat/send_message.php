<?php


session_start();
require_once "..\connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");  // PHP-ban átirányítás
    exit();  // Fontos, hogy leállítsd a további kód futtatását
}


// Hirdetés adatainak lekérdezése
if (isset($_GET['ad_id'])) {
    $ad_id = $_GET['ad_id'];
    $receiver_id = $_GET['receiver_id'];

    $sql = "SELECT ads.ad_id, ads.title, ads.description, ads.price, users.username 
            FROM ads 
            JOIN users ON ads.user_id = users.user_id 
            WHERE ads.ad_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ad_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $ad = $result->fetch_assoc();
    } else {
        die("Hirdetés nem található.");
    }

    // Lekérdezés a hirdetéshez tartozó képekhez
    $sql_images = "SELECT image_url FROM ads_images WHERE ad_id = ?";
    $stmt_images = $conn->prepare($sql_images);
    $stmt_images->bind_param("i", $ad_id);
    $stmt_images->execute();
    $result_images = $stmt_images->get_result();
    $images = [];
    while ($row = $result_images->fetch_assoc()) {
        $images[] = $row['image_url'];
    }
} else {
    die("Érvénytelen hirdetés ID.");
}
?>

<?php require("../head.php"); ?>
<link rel="stylesheet" href="/techbazar/css/send_message.css">

    <div class="msgcontents">
        <div class="ad_details">
            <h2><?php echo htmlspecialchars($ad['title']); ?></h2>

            <!-- Carousel for Ad Images -->
            <?php if (!empty($images)): ?>
            <div class="carousel">
                <div class="carousel-images">
                    <?php foreach ($images as $index => $image): ?>
                        <img src="/techbazar/<?php echo htmlspecialchars($image); ?>" class="carousel-image <?php echo $index === 0 ? 'active' : ''; ?>" alt="Ad Image">
                    <?php endforeach; ?>
                </div>
                <button class="carousel-button prev" onclick="changeSlide(-1)">&#10094;</button>
                <button class="carousel-button next" onclick="changeSlide(1)">&#10095;</button>
            </div>
            <?php endif; ?>

            <p><strong>Leírás:</strong> <?php echo nl2br(htmlspecialchars(strip_tags($ad['description']))) ?></p>
            <p><strong>Ár:</strong> <?php echo number_format($ad['price'], 0, '', ' ') ?> Ft</p>
            <p><strong>Feladó:</strong> <?php echo htmlspecialchars($ad['username']) ?></p>
        </div>
        
        <!-- Üzenetküldés űrlap -->
        <form action="send_message_handler.php" method="POST" class="message_form">
        <input type="hidden" name="receiver_id" value="<?php echo $receiver_id; ?>">
        <input type="hidden" name="ad_id" value="<?php echo $ad_id; ?>">
        <textarea name="message" placeholder="Írja be üzenetét..." required></textarea>
        <button type="submit">Üzenet Küldése</button>
        </form>
    </div>

    <script>
        let currentSlide = 0;
        const slides = document.querySelectorAll('.carousel-image');

        function changeSlide(direction) {
            slides[currentSlide].classList.remove('active');
            currentSlide = (currentSlide + direction + slides.length) % slides.length;
            slides[currentSlide].classList.add('active');
        }
    </script>
</body>
</html>

<?php
// Adatbázis kapcsolat lezárása
$stmt->close();
$conn->close();
?>