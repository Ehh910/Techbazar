<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Hozzáférés megtagadva.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receiver_id = $_POST['receiver_id'];
    $message = $_POST['message'];
    $ad_id = $_POST['ad_id']; // Hirdetés azonosítója

    if (empty($message)) {
        die("Üzenet nem lehet üres.");
    }

    // Csatlakozás az adatbázishoz
    $servername = "localhost";
    $usernameDB = "root";
    $password = "";
    $dbname = "ujhasznal2";

    $conn = new mysqli($servername, $usernameDB, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Üzenet beszúrása az adatbázisba (ad_id-vel együtt)
    $sql = "INSERT INTO chat (sender_id, receiver_id, message, ad_id) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iisi", $_SESSION['user_id'], $receiver_id, $message, $ad_id);

    if ($stmt->execute()) {
        // Visszairányítás a chat_details.php oldalra a kiválasztott felhasználóval és hirdetéssel
        header("Location: chat_details.php?user_id=" . $receiver_id . "&ad_id=" . $ad_id);
    } else {
        echo "Hiba történt az üzenet küldése során.";
    }

    $stmt->close();
    $conn->close();
}
?>