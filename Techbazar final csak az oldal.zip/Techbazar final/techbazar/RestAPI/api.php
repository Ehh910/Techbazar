<?php
header('Content-Type: application/json');

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ujhasznal2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    sendResponse(500, ['error' => 'Database connection failed']);
    exit;
}

// Parse request - MODIFIED FOR techbazar/RestAPI/
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uriSegments = explode('/', trim($requestUri, '/'));

// Remove base path segments
$basePath = ['techbazar', 'RestAPI'];
foreach ($basePath as $path) {
    if (isset($uriSegments[0]) && $uriSegments[0] === $path) {
        array_shift($uriSegments);
    }
}

// Debug output (remove in production)
error_log("Request URI: " . $_SERVER['REQUEST_URI']);
error_log("Processed URI Segments: " . print_r($uriSegments, true));

// API routing
if (count($uriSegments) >= 2 && $uriSegments[0] === 'api' && $uriSegments[1] === 'locations') {
    $locationId = $uriSegments[2] ?? null;
    
    // Handle the request
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            if ($locationId) {
                getLocation($conn, $locationId);
            } else {
                getAllLocations($conn);
            }
            break;
            
        case 'POST':
            if ($locationId) {
                sendResponse(405, ['error' => 'Method not allowed for specific resource']);
            } else {
                createLocation($conn);
            }
            break;
            
        case 'PUT':
        case 'PATCH':
            if ($locationId) {
                updateLocation($conn, $locationId);
            } else {
                sendResponse(400, ['error' => 'Location ID required']);
            }
            break;
            
        case 'DELETE':
            if ($locationId) {
                deleteLocation($conn, $locationId);
            } else {
                sendResponse(400, ['error' => 'Location ID required']);
            }
            break;
            
        default:
            sendResponse(405, ['error' => 'Method not allowed']);
            break;
    }
} else {
    sendResponse(404, ['error' => 'Not found']);
}

$conn->close();

// Helper function to send consistent responses
function sendResponse($statusCode, $data) {
    http_response_code($statusCode);
    echo json_encode($data);
}

// ---- REST API Endpoints ----

/**
 * GET /api/locations
 * Get all locations
 */
function getAllLocations($conn) {
    $result = $conn->query("SELECT location_id, city_name FROM locations");
    $locations = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $locations[] = $row;
        }
    }
    
    sendResponse(200, $locations);
}

/**
 * GET /api/locations/{id}
 * Get a specific location
 */
function getLocation($conn, $id) {
    if (!is_numeric($id)) {
        sendResponse(400, ['error' => 'Invalid location ID']);
        return;
    }

    $stmt = $conn->prepare("SELECT location_id, city_name FROM locations WHERE location_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        sendResponse(200, $row);
    } else {
        sendResponse(404, ['error' => 'Location not found']);
    }
    $stmt->close();
}

/**
 * POST /api/locations
 * Create a new location
 */
function createLocation($conn) {
    $data = json_decode(file_get_contents("php://input"), true);
    
    // Validate input
    if (!isset($data['city_name']) || empty(trim($data['city_name']))) {
        sendResponse(400, ['error' => 'Missing or empty city_name']);
        return;
    }

    $cityName = trim($data['city_name']);
    $stmt = $conn->prepare("INSERT INTO locations (city_name) VALUES (?)");
    $stmt->bind_param("s", $cityName);
    
    if ($stmt->execute()) {
        $locationId = $conn->insert_id;
        $locationUrl = "/techbazar/RestAPI/api/locations/$locationId";
        
        header("Location: $locationUrl");
        sendResponse(201, [
            'success' => true,
            'message' => 'Location created',
            'data' => [
                'location_id' => $locationId,
                'city_name' => $cityName,
                'url' => $locationUrl
            ]
        ]);
    } else {
        sendResponse(500, ['error' => 'Database error: ' . $conn->error]);
    }
    $stmt->close();
}

/**
 * PUT /api/locations/{id}
 * Update an existing location (full update)
 */
function updateLocation($conn, $id) {
    if (!is_numeric($id)) {
        sendResponse(400, ['error' => 'Invalid location ID']);
        return;
    }

    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!isset($data['city_name']) || empty(trim($data['city_name']))) {
        sendResponse(400, ['error' => 'Missing or empty city_name']);
        return;
    }

    $cityName = trim($data['city_name']);
    $stmt = $conn->prepare("UPDATE locations SET city_name = ? WHERE location_id = ?");
    $stmt->bind_param("si", $cityName, $id);
    
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            sendResponse(200, [
                'success' => true,
                'message' => 'Location updated',
                'data' => [
                    'location_id' => $id,
                    'city_name' => $cityName
                ]
            ]);
        } else {
            sendResponse(404, ['error' => 'Location not found or no changes made']);
        }
    } else {
        sendResponse(500, ['error' => 'Database error: ' . $conn->error]);
    }
    $stmt->close();
}

/**
 * DELETE /api/locations/{id}
 * Delete a location
 */
function deleteLocation($conn, $id) {
    if (!is_numeric($id)) {
        sendResponse(400, ['error' => 'Invalid location ID']);
        return;
    }

    // First check if the resource exists
    $checkStmt = $conn->prepare("SELECT location_id FROM locations WHERE location_id = ?");
    $checkStmt->bind_param("i", $id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    $checkStmt->close();
    
    if ($checkResult->num_rows === 0) {
        sendResponse(404, ['error' => 'Location not found']);
        return;
    }

    // Delete the resource
    $stmt = $conn->prepare("DELETE FROM locations WHERE location_id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        sendResponse(200, [
            'success' => true,
            'message' => 'Location deleted'
        ]);
    } else {
        sendResponse(500, ['error' => 'Database error: ' . $conn->error]);
    }
    $stmt->close();
}
?>