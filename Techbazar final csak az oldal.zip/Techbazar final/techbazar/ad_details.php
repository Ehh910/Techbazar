<?php
session_start();

// Ha nincs bejelentkezve a felhasználó, alapértelmezett értékek
$username = isset($_SESSION['username']) ? $_SESSION['username'] : null;
$profilepic = isset($_SESSION['profilepic']) ? $_SESSION['profilepic'] : null;

// Kijelentkezés kezelése
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset(); // Munkamenet adatok törlése
    session_destroy(); // Munkamenet befejezése
    header("Location: index.php"); // Átirányítás
    exit();
}

// Csatlakozás az adatbázishoz
$servername = "localhost";
$usernameDB = "root";
$password = "";
$dbname = "ujhasznal2";

$conn = new mysqli($servername, $usernameDB, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Hirdetés lekérdezése
if (isset($_GET['ad_id'])) {
    $ad_id = $_GET['ad_id'];

    // Hirdetés adatainak lekérdezése
    $sql = "SELECT ads.ad_id, ads.title, ads.description, ads.price, locations.city_name, locations.postal_code, ads.creation_date, 
    users.username AS user_name, users.profilepic AS user_profilepic, 
    categories.category_name, brands.name AS brand_name, 
    GROUP_CONCAT(ads_images.image_url) AS image_urls, ads.user_id, ads.shipping_method_flag
    FROM ads
    JOIN users ON ads.user_id = users.user_id
    JOIN locations ON ads.location_id = locations.location_id
    JOIN types ON ads.type_id = types.type_id
    JOIN subcategories ON types.subcategory_id = subcategories.subcategory_id
    JOIN categories ON subcategories.category_id = categories.category_id
    JOIN brands ON types.brand_id = brands.brand_id
    JOIN ads_images ON ads.ad_id = ads_images.ad_id
    WHERE ads.ad_id = ?
    GROUP BY ads.ad_id";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ad_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $ad = $result->fetch_assoc();
        $user_id = $ad['user_id']; // A feladó user_id-ját elmentjük
        $imageUrls = explode(',', $ad['image_urls']); // Képek URL-jeit tömbbe mentjük
    } else {
        echo "Hirdetés nem található.";
        exit();
    }
} else {
    echo "Érvénytelen hirdetés ID.";
    exit();
}

// Hirdetés feladása óta eltelt idő kiszámítása
$creationDate = $ad['creation_date'];
$currentDate = new DateTime();
$creationDateTime = new DateTime($creationDate);
$interval = $currentDate->diff($creationDateTime);

if ($interval->y > 0) {
    $timeString = $interval->y . ' évvel ezelőtt';
} elseif ($interval->m > 0) {
    $timeString = $interval->m . ' hónappal ezelőtt';
} elseif ($interval->d > 0) {
    $timeString = $interval->d . ' nappal ezelőtt';
} elseif ($interval->h > 0) {
    $timeString = $interval->h . ' órával ezelőtt';
} elseif ($interval->i > 0) {
    $timeString = $interval->i . ' perccel ezelőtt';
} else {
    $timeString = $interval->s . ' másodperccel ezelőtt';
}

// Kérés küldése (megvettem és értékelés kérés)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_purchase'])) {
    // Ellenőrizni, hogy a felhasználó nem próbálja-e értékelni saját hirdetését
    if ($_SESSION['user_id'] !== $user_id) {
        $sql = "INSERT INTO reviews (reviewer_id, reviewed_id, review_date, status) VALUES (?, ?, NOW(), 'pending')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $_SESSION['user_id'], $user_id);

        if ($stmt->execute()) {
            echo "Az értékelési kérelmet sikeresen elküldtük.";
        } else {
            echo "Hiba történt a kérés elküldése során.";
        }
    } else {
        echo "Nem értékelheted saját hirdetésedet.";
    }
}
?>

<?php require "head.php"; ?>
<link rel="stylesheet" href="/techbazar/css/ad_details.css">

<div class="hirdetescontainer">
    <div class="ad_card_details">
        <h2><?php echo htmlspecialchars($ad['title']); ?></h2>
<!--Javitott rész, Mostmár bejelentkezés nélkül is látszik a felhasználó neve es képe  (a profile div az)-->
        <hr>
        <div class="profile">
            <a href="profile.php?user_id=<?php echo $user_id; ?>">
                <img class="profilecss" src="<?php echo !empty($ad['user_profilepic']) ? htmlspecialchars($ad['user_profilepic']) : 'default_profiles/default.png'; ?>" alt="Profilkép">
            </a>
            <a href="profile.php?user_id=<?php echo $user_id; ?>">
                <span><?php echo !empty($ad['user_name']) ? htmlspecialchars($ad['user_name']) : 'Ismeretlen felhasználó'; ?></span>
            </a>
        </div>
        <div class="adimgbckgrd">
            <div class="image-carousel">
                <div class="adimg">
                    <?php foreach ($imageUrls as $index => $imageUrl): ?>
                        <img src="<?php echo htmlspecialchars($imageUrl); ?>" class="carousel-image <?php echo $index === 0 ? 'active' : ''; ?>" alt="Hirdetés kép <?php echo $index + 1; ?>">
                    <?php endforeach; ?>
                </div>
                <div class="carouselbtns">
                    <button class="carousel-button prev" onclick="prevImage()">❮</button>
                    <button class="carousel-button next" onclick="nextImage()">❯</button>
                </div>
            </div>
        </div>
        <hr>
        <div class="timereport">
            <p>Feladva: <?php echo $timeString; ?></p>
            <!-- Hirdetés jelentése gomb -->
            <button onclick="openPopup('admin_panel/report_ad.php?ad_id=<?php echo $ad_id; ?>')">Hirdetés jelentése</button>                 
        </div>

        <div class="ad_details_layout">
            <p><strong>Leírás:</strong></p>
            <div class="description_box">
                <?php echo nl2br(htmlspecialchars(strip_tags(($ad['description'])))); ?>
            </div>
            <div class="location_shipping">
                <p><strong>Helyszín:</strong> <?php echo htmlspecialchars($ad['postal_code'] . ", " . $ad['city_name']); ?></p>
                <p><strong>Szállítási mód:</strong> 
                    <?php echo ($ad['shipping_method_flag'] == 1) ? "Csomagküldés" : "Személyes átvétel"; ?>
                </p>
            </div>
            <p><strong>Ár:</strong> <?php echo htmlspecialchars($ad['price']); ?> Ft</p>
            <a 
               <?php if (!isset($_SESSION['user_id'])): ?>
                   href="#" onclick="openPopup('login.php'); return false;"
               <?php else: ?>
                   href="Chat/send_message.php?ad_id=<?php echo $ad_id; ?>&receiver_id=<?php echo $user_id; ?>"
               <?php endif; ?>>
                <button class="send_message_button">Üzenet Küldése az eladónak</button>
            </a>
        </div>
    </div>
</div>

<?php require "footer.php"; ?>

<div id="popupModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closePopup()">&times;</span>
        <iframe id="popupFrame" name="popupFrame" src=""></iframe>
    </div>
</div>

<script>
    let currentImageIndex = 0;
    const images = document.querySelectorAll('.carousel-image');

    function showImage(index) {
        images.forEach((img, i) => {
            img.classList.remove('active');
            if (i === index) {
                img.classList.add('active');
            }
        });
    }

    function prevImage() {
        currentImageIndex = (currentImageIndex > 0) ? currentImageIndex - 1 : images.length - 1;
        showImage(currentImageIndex);
    }

    function nextImage() {
        currentImageIndex = (currentImageIndex < images.length - 1) ? currentImageIndex + 1 : 0;
        showImage(currentImageIndex);
    }

    function openPopup(pageUrl) {
        document.getElementById("popupFrame").src = pageUrl;
        document.getElementById("popupModal").style.display = "flex";
    }

    function closePopup() {
        document.getElementById("popupModal").style.display = "none";
        document.getElementById("popupFrame").src = "";
        setTimeout(()=> {location.reload()}, 50);
    }
</script>
</body>
</html>

<?php
// Adatbázis kapcsolat lezárása
$stmt->close();
$conn->close();
?>
