<?php
$host = 'localhost';
$dbname = 'ujhasznal2';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Adatbázis kapcsolódási hiba: " . $e->getMessage());

}
session_start();
require_once __DIR__ . '..\auth.php';
requireAdmin();

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Főoldal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">Felhasználók</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ads.php">Hirdetések</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Feljelentések</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</body>
</html>

<?php

$ads = $conn->query("SELECT ad_id, title, creation_date, user_id FROM ads")->fetchAll();
?>

<h1>Hirdetések kezelése</h1>

<table class="table">
    <thead>
        <tr>
            <th>Cím</th>
            <th>Feladás dátuma</th>
            <th>Felhasználó</th>
            <th>Műveletek</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($ads as $ad): ?>
        <tr>
            <td><?= $ad['title'] ?></td>
            <td><?= $ad['creation_date'] ?></td>
            <td><?= $ad['user_id'] ?></td>
            <td>
                <a href="..\ad_details.php?ad_id=<?= $ad['ad_id'] ?>" class="btn btn-success">Megtekintés</a>
                <a href="delete_ad.php?id=<?= $ad['ad_id'] ?>" class="btn btn-danger">Törlés</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

