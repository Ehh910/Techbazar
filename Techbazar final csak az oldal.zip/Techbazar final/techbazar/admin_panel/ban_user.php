<?php
$host = 'localhost';
$dbname = 'ujhasznal2';
$username = 'root';
$password = '';


session_start();
require_once __DIR__ . '..\auth.php';
requireAdmin();


try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Adatbázis kapcsolódási hiba: " . $e->getMessage());
}
if (isset($_POST['user_id']) && isset($_POST['reason'])) {
    $user_id = $_POST['user_id'];
    $reason = $_POST['reason'];

    // Ellenőrizzük, hogy az ID szám-e
    if (is_numeric($user_id)) {
        // Felhasználó kitiltása és az indoklás mentése
        $stmt = $conn->prepare("UPDATE users SET banned = 1, ban_reason = ? WHERE user_id = ?");
        $stmt->execute([$reason, $user_id]);

        // Visszairányítás a felhasználók listájára
        header("Location: users.php");
        exit();
    } else {
        die("Érvénytelen felhasználói ID.");
    }
} else {
    die("Hiányzó adatok.");
}
?>