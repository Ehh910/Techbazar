<?php
$host = 'localhost';
$dbname = 'ujhasznal2';
$username = 'root';
$password = '';


session_start();
require_once __DIR__ . '..\auth.php';
requireAdmin();


try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Adatbázis kapcsolódási hiba: " . $e->getMessage());
}

// Ellenőrizzük, hogy az ID paraméter meg van-e adva
if (isset($_GET['id'])) {
    $ad_id = $_GET['id'];

    // Ellenőrizzük, hogy az ID szám-e
    if (is_numeric($ad_id)) {
        // Hirdetés törlése az adatbázisból
        $stmt = $conn->prepare("DELETE FROM ads WHERE ad_id = ?");
        $stmt->execute([$ad_id]);

        // Visszairányítás a hirdetések listájára
        header("Location: ads.php");
        exit();
    } else {
        die("Érvénytelen hirdetési ID.");
    }
} else {
    die("Nincs megadva hirdetési ID.");
}
?>