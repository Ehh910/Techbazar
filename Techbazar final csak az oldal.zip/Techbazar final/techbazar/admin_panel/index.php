<?php
$host = 'localhost';
$dbname = 'ujhasznal2';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Adatbázis kapcsolódási hiba: " . $e->getMessage());
}

session_start();
require_once __DIR__ . '..\auth.php';
requireAdmin();


?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="..\index.php">Főoldal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">Felhasználók</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ads.php">Hirdetések</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Jelentések</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</body>
</html>

<?php

// Statisztikák lekérdezése
$total_users = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch()['total'];
$total_ads = $conn->query("SELECT COUNT(*) AS total FROM ads")->fetch()['total'];
$total_reports = $conn->query("SELECT COUNT(*) AS total FROM reports")->fetch()['total'];

// Legutóbb regisztrált felhasználók
$recent_users = $conn->query("SELECT username, registration_date, last_login FROM users ORDER BY registration_date DESC LIMIT 5")->fetchAll();

// Legújabb hirdetések
$recent_ads = $conn->query("SELECT title, creation_date FROM ads ORDER BY creation_date DESC LIMIT 5")->fetchAll();

// Legújabb feljelentések
$recent_reports = $conn->query("SELECT r.reason, r.created_at, u1.username AS reporter, u2.username AS reported 
                                FROM reports r 
                                JOIN users u1 ON r.reporter_id = u1.user_id 
                                JOIN users u2 ON r.reported_id = u2.user_id 
                                ORDER BY r.created_at DESC LIMIT 5")->fetchAll();
?>

<h1>Főoldal</h1>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Regisztrált felhasználók</h5>
                <p class="card-text"><?= $total_users ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Feladott hirdetések</h5>
                <p class="card-text"><?= $total_ads ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Jelentések</h5>
                <p class="card-text"><?= $total_reports ?></p>
            </div>
        </div>
    </div>
</div>
<h2 class="mt-4">Legutóbb regisztrált felhasználók</h2>
<table class="table">
    <thead>
        <tr>
            <th>Felhasználónév</th>
            <th>Regisztráció dátuma</th>
            <th>Legutóbbi bejelentkezés dátuma</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($recent_users as $user): ?>
        <tr>
            <td><?= $user['username'] ?></td>
            <td><?= $user['registration_date'] ?></td>
            <td><?= $user['last_login'] ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

