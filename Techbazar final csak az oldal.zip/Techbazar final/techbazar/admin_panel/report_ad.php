<?php
session_start();
require_once "..\connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");  // PHP-ban átirányítás
    exit();  // Fontos, hogy leállítsd a további kód futtatását
}

if (!isset($_GET['ad_id'])) {
    die("Érvénytelen hirdetés ID.");
}




$ad_id = $_GET['ad_id'];
$reporter_id = $_SESSION['user_id'];

// Ellenőrizzük, hogy a felhasználó nem jelentheti saját hirdetését
$sql = "SELECT user_id FROM ads WHERE ad_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $ad_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Hirdetés nem található.");
}

$ad = $result->fetch_assoc();
$reported_id = $ad['user_id'];

if ($reported_id === $reporter_id) {
    die("Nem jelentheted saját hirdetésedet.");
}

// Feldolgozzuk az űrlapot, ha elküldték
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_report'])) {
    $reason = $_POST['reason'];
    
    // Beszúrjuk az adatbázisba
    $sql = "INSERT INTO reports (reporter_id, reported_id, ad_id, reason, status, created_at) 
            VALUES (?, ?, ?, ?, 0, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiis", $reporter_id, $reported_id, $ad_id, $reason);
    
    if ($stmt->execute()) {
        echo "<script>alert('A jelentés sikeresen elküldve!'); window.parent.closePopup();</script>";
    } else {
        echo "<script>alert('Hiba történt a jelentés elküldése közben.');</script>";
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hirdetés jelentése</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .report-form {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            max-width: 500px;
            margin: 0 auto;
        }
        textarea {
            width: 100%;
            height: 150px;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            resize: vertical;
        }
        button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="report-form">
        <h2>Hirdetés jelentése</h2>
        <p>Kérjük, indokolja meg, miért szeretné jelenteni ezt a hirdetést.</p>
        
        <form method="POST">
            <textarea name="reason" required placeholder="Adja meg a jelentés okát..."></textarea>
            <button type="submit" name="submit_report">Jelentés elküldése</button>
        </form>
    </div>
</body>
</html>