<?php
$host = 'localhost';
$dbname = 'ujhasznal2';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Adatbázis kapcsolódási hiba: " . $e->getMessage());
}

session_start();
require_once __DIR__ . '..\auth.php';
requireAdmin();


?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style/style.css">
    <style>
        .reason-text {
            max-width: 300px;
            word-wrap: break-word;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Főoldal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">Felhasználók</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ads.php">Hirdetések</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="reports.php">Jelentések</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

<div class="container mt-4">
    <h1>Jelentések kezelése</h1>


        <?php
    // Üzenet megjelenítése, ha van
    if (isset($_GET['message'])) {
        echo '<div class="alert alert-info">' . htmlspecialchars($_GET['message']) . '</div>';
    }
    ?>

    <?php
    $reports = $conn->query("
        SELECT r.report_id, r.reason, r.created_at, r.ad_id, r.status,
               u1.username AS reporter, u2.username AS reported,
               a.title AS ad_title
        FROM reports r 
        JOIN users u1 ON r.reporter_id = u1.user_id 
        JOIN users u2 ON r.reported_id = u2.user_id
        LEFT JOIN ads a ON r.ad_id = a.ad_id
        ORDER BY r.created_at DESC
    ")->fetchAll();
    ?>

    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>Jelentő</th>
                <th>Jelentett</th>
                <th>Hirdetés</th>
                <th>Indok</th>
                <th>Dátum</th>
                <th>Státusz</th>
                <th>Műveletek</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reports as $report): ?>
            <tr>
                <td><?= htmlspecialchars($report['reporter']) ?></td>
                <td><?= htmlspecialchars($report['reported']) ?></td>
                <td>
                    <?php if ($report['ad_id']): ?>
                        <a href="..\ad_details.php?ad_id=<?= $report['ad_id'] ?>" target="_blank">
                            <?= htmlspecialchars($report['ad_title']) ?>
                        </a>
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td class="reason-text"><?= htmlspecialchars($report['reason']) ?></td>
                <td><?= $report['created_at'] ?></td>
                <td>
                    <?php 
                    switch($report['status']) {
                        case 0: echo '<span class="badge bg-warning">Függőben</span>'; break;
                        case 1: echo '<span class="badge bg-success">Elfogadva</span>'; break;
                        case 2: echo '<span class="badge bg-danger">Elutasítva</span>'; break;
                    }
                    ?>
                </td>
                <td>
                    <div class="d-flex gap-2">
                        <a href="resolve_report.php?id=<?= $report['report_id'] ?>&action=approve" class="btn btn-sm btn-success">Elbírálás</a>
                        <a href="resolve_report.php?id=<?= $report['report_id'] ?>&action=reject" class="btn btn-sm btn-danger">Elutasítás</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>