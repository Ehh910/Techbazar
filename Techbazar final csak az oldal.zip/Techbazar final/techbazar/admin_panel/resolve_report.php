<?php
session_start();
require_once __DIR__ . '/../connect.php'; // Figyeljünk a perjel irányára

// Ellenőrizzük, hogy admin-e a felhasználó
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    die("Hozzáférés megtagadva!");
}

if (!isset($_GET['id']) || !isset($_GET['action'])) {
    die("Hiányzó paraméterek!");
}

$report_id = $_GET['id'];
$action = $_GET['action'];

// Ellenőrizzük a jelentés létezését
$sql = "SELECT * FROM reports WHERE report_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $report_id);
$stmt->execute();
$result = $stmt->get_result();
$report = $result->fetch_assoc();

// Fontos: fogyasszuk el az összes eredményt
while ($conn->more_results()) {
    $conn->next_result();
    if ($res = $conn->store_result()) {
        $res->free();
    }
}

if (!$report) {
    die("A jelentés nem található!");
}

// Feldolgozzuk a kérést
if ($action === 'approve') {
    $status = 1;
    $message = "A jelentést sikeresen elfogadtuk.";
} elseif ($action === 'reject') {
    $status = 2;
    $message = "A jelentést elutasítottuk.";
} else {
    die("Érvénytelen művelet!");
}

// Frissítjük az állapotot
$sql = "UPDATE reports SET status = ? WHERE report_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $status, $report_id);
$stmt->execute();

// Fogyasszuk el az utolsó eredményt is
while ($conn->more_results()) {
    $conn->next_result();
    if ($res = $conn->store_result()) {
        $res->free();
    }
}

header("Location: reports.php?message=" . urlencode($message));
exit();
?>