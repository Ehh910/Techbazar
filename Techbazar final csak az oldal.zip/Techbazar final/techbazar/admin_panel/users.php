<?php
$host = 'localhost';
$dbname = 'ujhasznal2';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Adatbázis kapcsolódási hiba: " . $e->getMessage());
}

session_start();
require_once __DIR__ . '..\auth.php';
requireAdmin();

// Search functionality
$search = isset($_GET['search']) ? $_GET['search'] : '';
$where = '';
if (!empty($search)) {
    $where = " WHERE username LIKE :search";
}

// Query to get users with optional search
$query = "SELECT user_id, username, registration_date, last_login, banned FROM users" . $where;
$stmt = $conn->prepare($query);

if (!empty($search)) {
    $searchParam = "%$search%";
    $stmt->bindParam(':search', $searchParam);
}

$stmt->execute();
$users = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Főoldal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">Felhasználók</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ads.php">Hirdetések</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Feljelentések</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h1>Felhasználók kezelése</h1>
        
        <!-- Search Form -->
        <div class="row mb-4">
            <div class="col-md-6">
                <form method="GET" action="users.php">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="Felhasználónév keresése..." value="<?= htmlspecialchars($search) ?>">
                        <button class="btn btn-primary" type="submit">Keresés</button>
                        <?php if (!empty($search)): ?>
                            <a href="users.php" class="btn btn-outline-secondary">Összes</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Bootstrap Modal -->
        <div class="modal fade" id="banModal" tabindex="-1" aria-labelledby="banModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="banModalLabel">Felhasználó kitiltása</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="banForm" action="ban_user.php" method="POST">
                            <input type="hidden" id="banUserId" name="user_id">
                            <div class="mb-3">
                                <label for="banReason" class="form-label">Indoklás</label>
                                <textarea class="form-control" id="banReason" name="reason" rows="3" required></textarea>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Mégse</button>
                        <button type="submit" form="banForm" class="btn btn-danger">Kitiltás</button>
                    </div>
                </div>
            </div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>Felhasználónév</th>
                    <th>Regisztráció dátuma</th>
                    <th>Utolsó bejelentkezés</th>
                    <th>Státusz</th>
                    <th>Műveletek</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="5" class="text-center">Nincs találat</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['registration_date']) ?></td>
                        <td><?= htmlspecialchars($user['last_login']) ?></td>
                        <td style="color: <?= $user['banned'] ? 'red' : 'green' ?>;">
                            <?= $user['banned'] ? 'Kitiltva' : 'Aktív' ?>
                        </td>
                        <td>
                            <?php if (!$user['banned']): ?>
                                <button type="button" class="btn btn-danger ban-btn" data-bs-toggle="modal" data-bs-target="#banModal" data-user-id="<?= $user['user_id'] ?>">
                                    Kitiltás
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- JavaScript a modal kezeléséhez -->
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        // Kitiltás gombok eseményfigyelője
        document.querySelectorAll('.ban-btn').forEach(button => {
            button.addEventListener('click', function () {
                // Beállítjuk a felhasználó ID-t a hidden inputba
                const userId = this.getAttribute('data-user-id');
                document.getElementById('banUserId').value = userId;
            });
        });
    });
    </script>

</body>
</html>