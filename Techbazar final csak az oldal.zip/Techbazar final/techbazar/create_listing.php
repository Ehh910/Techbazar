<?php
session_start();

// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['username']) || !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ujhasznal2";

// Csatlakozás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Helyszínek lekérdezése az API-ból
$apiUrl = 'http://localhost/techbazar/RestAPI/api/locations';
$locations = [];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

if ($response) {
    $locations = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $locations = []; // Hibás JSON esetén üres tömb
    }
}

// A bejelentkezett felhasználó adatai
$userUsername = $_SESSION['username'];
$profilepic = $_SESSION['profilepic'];
$userId = $_SESSION['user_id'];

// Fő kategóriák lekérdezése
$categoriesResult = $conn->query("SELECT * FROM categories");
$categories = $categoriesResult->fetch_all(MYSQLI_ASSOC);

// Al-kategóriák lekérdezése AJAX kérés esetén
if (isset($_GET['category_id'])) {
    $categoryId = (int)$_GET['category_id'];
    $subcategoriesResult = $conn->query("SELECT * FROM subcategories WHERE category_id = $categoryId");
    $subcategories = $subcategoriesResult->fetch_all(MYSQLI_ASSOC);
    echo json_encode($subcategories);
    exit();
}

// Márkák lekérdezése al-kategória alapján
if (isset($_GET['subcategory_id']) && isset($_GET['brand_request'])) {
    $subcategoryId = (int)$_GET['subcategory_id'];
    $brandsResult = $conn->query("SELECT * FROM brands WHERE subcategory_id = $subcategoryId");

    if ($brandsResult->num_rows > 0) {
        $brands = $brandsResult->fetch_all(MYSQLI_ASSOC);
        echo json_encode($brands);
    } else {
        echo json_encode([]);
    }
    exit();
}

// Típusok lekérdezése márka alapján
if (isset($_GET['subcategory_id']) && isset($_GET['brand_id'])) {
    $subcategoryId = (int)$_GET['subcategory_id'];
    $brandId = (int)$_GET['brand_id'];

    $typesResult = $conn->query("SELECT * FROM types WHERE subcategory_id = $subcategoryId AND brand_id = $brandId");
    if ($typesResult->num_rows > 0) {
        $types = $typesResult->fetch_all(MYSQLI_ASSOC);
        echo json_encode($types);
    } else {
        echo json_encode([]);
    }
    exit();
}

// Ha adatokat küldtek a formon, itt dolgozzuk fel őket
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $category = (int)$_POST['category'];
    $subcategory = (int)$_POST['subcategory'];
    $price = (int)$_POST['price'];
    $brand = (int)$_POST['brand'];
    $type = trim($_POST['type']);
    $shippingMethod = $_POST['shipping_method']; // Szállítási mód
    $location = (int)$_POST['location'];

    // Szállítási mód kód fordítása
    $shippingMethod = ($shippingMethod === 'delivery') ? 1 : 0;

    // Ellenőrizzük, hogy a típus ki lett-e választva
    if (empty($type)) {
        $error = "Kérjük, válasszon típust!";
    } else {
        // Képek feltöltése
        $imagePaths = [];
        if (!empty($_FILES['images']['name'][0])) { // Ha van feltöltött kép
            $uploadedFiles = $_FILES['images'];
            $fileCount = count($uploadedFiles['name']);

            // Ellenőrizzük, hogy ne legyen több mint 3 fájl
            if ($fileCount > 3) {
                $error = "Maximum 3 fájlt tölthetsz fel!";
            } else {
                $targetDir = "uploads/";
                for ($i = 0; $i < $fileCount; $i++) {
                    $filename = uniqid() . "_" . basename($uploadedFiles["name"][$i]); // Egyedi fájlnév
                    $targetFile = $targetDir . $filename;
                    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

                    // Csak képfájlok engedélyezése
                    if (in_array($imageFileType, ['jpg', 'jpeg', 'png', 'jfif', 'webp', 'heic', 'avif'])) {
                        if (move_uploaded_file($uploadedFiles["tmp_name"][$i], $targetFile)) {
                            $imagePaths[] = $targetFile; // A kép elérési útját hozzáadjuk a tömbhöz
                        } else {
                            $error = "A fájl feltöltése nem sikerült!";
                            break;
                        }
                    } else {
                        $error = "Csak képfájlok engedélyezettek!";
                        break;
                    }
                }
            }
        }

        // Ha nincs hiba, folytatjuk a hirdetés létrehozását
        if (!isset($error)) {
            // Típus ID lekérdezése (módosítva: a brand_id-t is szűrjük)
            $typeQuery = "SELECT type_id FROM types WHERE subcategory_id = ? AND brand_id = ? AND name = ?";
            $stmt = $conn->prepare($typeQuery);
            $stmt->bind_param("iis", $subcategory, $brand, $type);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $typeId = $result->fetch_assoc()['type_id'];

                // Hirdetés hozzáadása az adatbázishoz
                $insertAdQuery = "INSERT INTO ads 
                    (user_id, type_id, title, description, price, location_id, shipping_method_flag) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($insertAdQuery);

                if (!$stmt) {
                    die("Hiba az SQL előkészítésében: " . $conn->error);
                }

                // Paraméterek bindelése
                $stmt->bind_param(
                    "iissiii", 
                    $userId, 
                    $typeId, 
                    $title, 
                    $description, 
                    $price, 
                    $location, 
                    $shippingMethod
                );

                // Végrehajtás
                if ($stmt->execute()) {
                    $adId = $stmt->insert_id;

                    // Képek elérési útjainak mentése (ha vannak képek)
                    if (!empty($imagePaths)) {
                        $insertImageQuery = "INSERT INTO ads_images (ad_id, image_url) VALUES (?, ?)";
                        $stmt = $conn->prepare($insertImageQuery);
                        foreach ($imagePaths as $imagePath) {
                            $stmt->bind_param("is", $adId, $imagePath);
                            $stmt->execute();
                        }
                    }

                    $success = "A hirdetés sikeresen hozzáadva!";
                } else {
                    $error = "Hiba történt a hirdetés hozzáadása közben: " . $stmt->error;
                }
            } else {
                $error = "A kiválasztott típus nem létezik.";
            }
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($error)) {
        echo "<script>
            window.parent.closePopup(); // Close the popup
            window.parent.location.reload(); // Reload the parent page to reflect changes
        </script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/createlisting.css">
    <title>Hirdetés Feladása</title>
</head>
<body>
    <script>

        document.addEventListener("DOMContentLoaded", function () {
            const form = document.querySelector("form");
            const submitBtn = document.getElementById("submitBtn");

            function validateForm() {
                const requiredFields = form.querySelectorAll("[required]");
                let allFilled = true;

                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        allFilled = false;
                    }
                });

                submitBtn.disabled = !allFilled;
            };

            // Figyel minden input és select mező változására
            form.querySelectorAll("input[required], select[required], textarea[required]").forEach(input => {
                input.addEventListener("input", validateForm);
                input.addEventListener("change", validateForm);
            });

            validateForm(); // Kezdeti ellenőrzés betöltés után
        });

        function loadSubcategories(categoryId) {
            fetch(`?category_id=${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    const subcategorySelect = document.getElementById('subcategory');
                    subcategorySelect.innerHTML = '<option value="">Válassz al-kategóriát</option>';
                    data.forEach(subcategory => {
                        subcategorySelect.innerHTML += `<option value="${subcategory.subcategory_id}">${subcategory.subcategory_name}</option>`;
                    });
                })
                .catch(error => {
                    console.error('Hiba történt:', error);
                });
        }

        function loadBrands() {
            const brandSelect = document.getElementById('brand');
            const subcategoryId = document.getElementById('subcategory').value;

            if (!subcategoryId) {
                brandSelect.innerHTML = '<option value="">Válassz márkát</option>';
                return;
            }

            fetch(`?subcategory_id=${subcategoryId}&brand_request=true`)
                .then(response => response.json())
                .then(data => {
                    brandSelect.innerHTML = '<option value="">Válassz márkát</option>';
                    data.forEach(brand => {
                        brandSelect.innerHTML += `<option value="${brand.brand_id}">${brand.name}</option>`;
                    });
                })
                .catch(error => {
                    console.error('Hiba történt:', error);
                });
        }

        function loadTypes() {
            const typeSelect = document.getElementById('type');
            const subcategoryId = document.getElementById('subcategory').value;
            const brandId = document.getElementById('brand').value;

            if (!subcategoryId || !brandId) {
                typeSelect.innerHTML = '<option value="">Válass típust</option>';
                return;
            }

            fetch(`?subcategory_id=${subcategoryId}&brand_id=${brandId}`)
                .then(response => response.json())
                .then(data => {
                    typeSelect.innerHTML = '<option value="">Válass típust</option>';
                    data.forEach(type => {
                        typeSelect.innerHTML += `<option value="${type.name}">${type.name}</option>`;
                    });
                })
                .catch(error => {
                    console.error('Hiba történt:', error);
                });
        }

        function validateFiles(input) {
            const maxFiles = 3;
            if (input.files.length > maxFiles) {
                alert(`Maximum ${maxFiles} fájlt tölthetsz fel.`);
                input.value = ''; // Törli a kiválasztott fájlokat
            }
        }

        // A bemenet ellenőrzése
        function validateInput(input) {
            const maxWordLength = 22;
            const words = input.value.split(/\s+/); // Szavakra bontja a szöveget

            if (words.some(word => word.length > maxWordLength)) {
                alert("Egyedüli szavak hossza nem lehet több 22 karakternél");

                // Újraépíti a bemenetet, kizárva a túl hosszú szavakat
                input.value = words.map(word => 
                    word.length > maxWordLength ? word.slice(0, maxWordLength) : word
                ).join(" ");
            }
        }

        // A cím ellenőrzése
        function validateInputtitle(input) {
            const words = input.value.split(/\s+/); // Szavakra bontja a szöveget
            const maxWordLength = 22;
            const maxLength = 60;
            
            if (input.value.length > maxLength) {
                alert("A cím hossza nem lehet több mint 60 karakter");
                input.value = input.value.slice(0, maxLength); // Levágja a maximális hosszra
            }

            if (words.some(word => word.length > maxWordLength)) {
                alert("Egyedüli szavak hossza nem lehet több 22 karakternél");
                input.value = input.value.slice(0, -1); // Eltávolítja az utolsó karaktert
            }
        }

        // Előnézet megjelenítése
        function showPreview(event) {
            event.preventDefault(); // Megakadályozza az űrlap elküldését
            
            console.log("Előnézet gomb megnyomva"); // Hibakereséshez

            // Értékek lekérése az űrlapról
            let title = document.getElementById("title")?.value || "Nincs cím megadva";
            let brand = document.getElementById("brand")?.selectedOptions[0]?.text || "Nincs kiválasztva";
            let description = document.getElementById("description")?.value || "Nincs leírás megadva";
            let price = document.getElementById("price")?.value || "0";
            let shipping = document.getElementById("shipping_method")?.selectedOptions[0]?.text || "Nincs kiválasztva";

            console.log({ title, brand, description, price, shipping }); // Hibakereséshez

            // Előnézeti tartalom frissítése
            document.getElementById("previewTitle").textContent = title;
            document.getElementById("previewBrand").textContent = "Márka: " + brand;
            document.getElementById("previewDescription").textContent = "Leírás: " + description;
            document.getElementById("previewPrice").textContent = price + " Ft";
            document.getElementById("previewShipping").textContent = shipping;

            // Kép előnézet kezelése
            let imageInput = document.getElementById("images");
            let previewImage = document.getElementById("previewImage");

            if (imageInput?.files && imageInput.files.length > 0) {
                let reader = new FileReader();
                reader.onload = function (e) {
                    previewImage.src = e.target.result;
                    previewImage.style.display = "block";
                };
                reader.readAsDataURL(imageInput.files[0]);
            } else {
                console.warn("No image selected");
                previewImage.style.display = "none";
            }

            // Show the preview card
            document.getElementById("previewCard").style.display = "block";
        }

        // Attach event listener to the preview button
        document.getElementById("previewButton")?.addEventListener("click", showPreview);
    </script>
<header>
    <h1>Adok-Veszek - Hirdetés Feladása</h1>
</header>

<main>
    <div class="bodystyle">
        <?php if (isset($success)): ?>
            <p class="success"><?php echo htmlspecialchars($success); ?></p>
        <?php elseif (isset($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <label for="title">Hirdetés címe:</label>
            <input type="text" id="title" name="title" oninput="validateInputtitle(this)" required>
            
            <label for="category">Fő kategória:</label>
            <select id="category" name="category" onchange="loadSubcategories(this.value)" required>
                <option value="">Válassz fő kategóriát</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['category_id']; ?>">
                        <?php echo htmlspecialchars($category['category_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="subcategory">Al-kategória:</label>
            <select id="subcategory" name="subcategory" onchange="loadBrands()" required>
                <option value="">Válassz al-kategóriát</option>
            </select>

            <label for="brand">Márka:</label>
            <select id="brand" name="brand" onchange="loadTypes()" required>
                <option value="">Válassz márkát</option>
            </select>

            <label for="type">Típus:</label>
            <select id="type" name="type" required>
                <option value="">Válassz típust</option>
            </select>

            <label for="description">Leírás:</label>
            <textarea style="resize: none;" id="description" name="description" oninput="validateInput(this)" required></textarea>

            <label for="price">Ár:</label>
            <input type="number" id="price" name="price" required>

            <label for="images">Képek(max 3):</label><!--maximum 3 kép-->
            <input type="file" id="images" name="images[]" multiple accept="image/*" onchange="validateFiles(this)">

            <label for="shipping_method">Szállítási mód:</label>
            <select id="shipping_method" name="shipping_method" required>
                <option value="">Válassz szállítási módot</option>
                <option value="personal">Személyes átvétel</option>
                <option value="delivery">Csomagküldés</option>
            </select>

            <label for="location">Helyszín:</label>
            <select id="location" name="location"  required >
                <option  value="">Válassz helyszínt</option>
                <?php foreach ($locations as $location): ?>
                    <option value="<?php echo $location['location_id'];  ?>">
                        <?php echo htmlspecialchars($location['city_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" id="submitBtn" disabled onclick="window.parent.closePopup()">Hirdetés feladása</button>

            <button type="button" id="previewButton" hidden>Hirdetés bemutatása</button>
        </form>
    </div>

    <div class="items">
    <div class="item" id="previewCard" style="display: none;">
        <img id="previewImage" src="" alt="Hirdetés kép" style="display: none; max-width: 100%;">
        <div class="details">
            <h3 class="cardh3title" id="previewTitle">Nincs cím megadva</h3>
            <hr>
            <p id="previewBrand">Márka: Nincs kiválasztva</p>
            <p class="descriptionp" id="previewDescription">Leírás: Nincs leírás megadva</p>
            <p class="price"><span id="previewPrice">0</span> Ft</p>
            <p class="shipping-method"><strong>Szállítási mód: </strong><span id="previewShipping">Nincs kiválasztva</span></p>
        </div>
    </div>
</div>
</div>

<script>
function validateInput(input) {
    const maxWordLength = 22;
    const words = input.value.split(/\s+/); // Szavakra bontja a szöveget

    if (words.some(word => word.length > maxWordLength)) {
        alert("Egyedüli szavak hossza nem lehet több 22 karakternél");

        // Újraépíti a bemenetet, kizárva a túl hosszú szavakat
        input.value = words.map(word => 
            word.length > maxWordLength ? word.slice(0, maxWordLength) : word
        ).join(" ");
    }
}

function validateInputtitle(input) {
    const words = input.value.split(/\s+/); // Szavakra bontja a szöveget
    const maxWordLength = 22;
    const maxLength = 60;
    
    if (input.value.length > maxLength) {
        alert("A cím hossza nem lehet több mint 60 karakter");
        input.value = input.value.slice(0, maxLength); // Levágja a maximális hosszra
    }

    if (words.some(word => word.length > maxWordLength)) {
        alert("Egyedüli szavak hossza nem lehet több 22 karakternél");
        input.value = input.value.slice(0, -1); // Eltávolítja az utolsó karaktert
    }
}

function showPreview(event) {
    event.preventDefault(); // Megakadályozza az űrlap elküldését
    
    console.log("Előnézet gomb megnyomva"); // Hibakereséshez

    // Értékek lekérése az űrlapról
    let title = document.getElementById("title")?.value || "Nincs cím megadva";
    let brand = document.getElementById("brand")?.selectedOptions[0]?.text || "Nincs kiválasztva";
    let description = document.getElementById("description")?.value || "Nincs leírás megadva";
    let price = document.getElementById("price")?.value || "0";
    let shipping = document.getElementById("shipping_method")?.selectedOptions[0]?.text || "Nincs kiválasztva";

    console.log({ title, brand, description, price, shipping }); // Hibakereséshez

    // Előnézeti tartalom frissítése
    document.getElementById("previewTitle").textContent = title;
    document.getElementById("previewBrand").textContent = "Márka: " + brand;
    document.getElementById("previewDescription").textContent = "Leírás: " + description;
    document.getElementById("previewPrice").textContent = price + " Ft";
    document.getElementById("previewShipping").textContent = shipping;

    // Kép előnézet kezelése
    let imageInput = document.getElementById("images");
    let previewImage = document.getElementById("previewImage");

    if (imageInput?.files && imageInput.files.length > 0) {
        let reader = new FileReader();
        reader.onload = function (e) {
            previewImage.src = e.target.result;
            previewImage.style.display = "block";
        };
        reader.readAsDataURL(imageInput.files[0]);
    } else {
        console.warn("No image selected");
        previewImage.style.display = "none";
    }

    // Show the preview card
    document.getElementById("previewCard").style.display = "block";
}

// Attach event listener to the preview button
document.getElementById("previewButton")?.addEventListener("click", showPreview);
</script>
</main>
</body>
</html>