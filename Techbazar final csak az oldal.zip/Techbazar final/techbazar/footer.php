<footer>
    <link rel="stylesheet" href="/techbazar/css/footer.css"> 
    <div class="footercontent">
        <div class="footer-logo-container">
            <img src="/techbazar/images/Logo_footer-removebg-preview.png" alt="FooterLogo" class="footer-logo"> <!-- Use absolute path for the image -->
            <p class="footer-description">
                Szerzői jogi védelem alatt álló oldal. A honlapon elhelyezett szöveges és képi anyagok, arculati és tartalmi elemek 
                (pl. betűtípusok, gombok, linkek, ikonok, szöveg, kép, grafika, logo stb.) felhasználása, másolása, terjesztése, 
                továbbítása - akár részben, vagy egészben - kizárólag a TechBazár előzetes, írásos beleegyezésével lehetséges.
            </p>
        </div>
        <p class="footer-logo-text">Minden jog fenntartva</p>
    </div>
</footer>