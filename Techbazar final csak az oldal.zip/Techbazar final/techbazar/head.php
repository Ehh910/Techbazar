<!DOCTYPE html>
<html lang="hu"></html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adok-Veszek</title>
    <link rel="stylesheet" href="/techbazar/css/style.css">
    <link rel="stylesheet" href="/techbazar/css/header.css">
    <link rel="stylesheet" href="/techbazar/css/body.css">
</head>
<header>
        <h1 class="HeaderLogo"><a href="/techbazar/index.php"><img src="/techbazar/images/logo-removebg-preview.png" alt="Logo"></a></h1>
            <nav class="navbar">
                <?php if (isset($_SESSION['username']) && !empty($_SESSION['username'])): ?>
                    <div class="user-info">
                        <a href="/techbazar/profile.php"><span><?php echo htmlspecialchars($_SESSION['username']); ?></span></a>
                        <a href="/techbazar/profile.php"><img class="profilecss" src="/techbazar/<?php echo htmlspecialchars($_SESSION['profilepic']); ?>" alt="Profilkép"></a>
                    </div>
                    <button id="headerbtn" onclick="location.href='/techbazar/logout.php?action=logout'">Kijelentkezés</button>
                    <button id="headerbtn" onclick="openPopup('/techbazar/create_listing.php')">Hirdetés feladása</button>
                    <button id="headerbtn" onclick="location.href='/techbazar/myads.php'">Hirdetéseim</button>
                    <?php if (basename($_SERVER['PHP_SELF']) === 'chat.php'): ?>
                        <button id="headerbtn" onclick="location.reload()">Üzeneteim</button>
                    <?php else: ?>
                        <button id="headerbtn" onclick="location.href='/techbazar/Chat/chat.php'">Üzeneteim</button>
                    <?php endif; ?>
                <?php else: ?>
                    <button id="headerbtn" onclick="openPopup('/techbazar/login.php')">Bejelentkezés</button>
                <?php endif; ?>
            </nav>
    </header>
<body>