<?php
session_start();

// Ha nincs bejelentkezve a felhasználó, alapértelmezett értékek
$username = isset($_SESSION['username']) ? $_SESSION['username'] : null;
$profilepic = isset($_SESSION['profilepic']) ? $_SESSION['profilepic'] : null;

// Kijelentkezés kezelése
require "logout.php";
//adatbázis kapcsolat behúzása
require "connect.php";

// Keresési kifejezés
$search_filter = "";
if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $search_term = $conn->real_escape_string(trim($_GET['search']));
    $search_filter = " AND (ads.title LIKE '%$search_term%' OR ads.description LIKE '%$search_term%' OR brands.name LIKE '%$search_term%')";
}

// Kategória szűrés
$category_filter = "";
if (isset($_GET['category'])) {
    $category = $_GET['category'];
    $category_filter = " AND categories.category_name = '" . $conn->real_escape_string($category) . "'";
}

// Alkategória szűrés
$subcategory_filter = "";
if (isset($_GET['subcategory'])) {
    $subcategory = $conn->real_escape_string($_GET['subcategory']);
    $subcategory_filter = " AND subcategories.subcategory_id = '$subcategory'";
}

// Ár szűrés
$price_filter = "";
if (isset($_GET['min-price']) && $_GET['min-price'] !== '') {
    $min_price = (int) $_GET['min-price'];
    $price_filter .= " AND ads.price >= $min_price";
}
if (isset($_GET['max-price']) && $_GET['max-price'] !== '') {
    $max_price = (int) $_GET['max-price'];
    $price_filter .= " AND ads.price <= $max_price";
}

// Szállítási mód szűrés
$shipping_filter = "";
if (isset($_GET['shipping'])) {
    $shipping_filter = " AND ads.shipping_method_flag = 1"; // Ha a checkbox be van jelölve
}

// Vármegye szűrés
$county_filter = "";
if (isset($_GET['county']) && $_GET['county'] !== '') {
    $county = $conn->real_escape_string($_GET['county']);
    $county_filter = " AND locations.city_name = '$county'";
}

// subcategóriák
$subcategories_list = [];
if (isset($_GET['category'])) {
    $sub_sql = "SELECT subcategory_name FROM subcategories 
                JOIN categories ON subcategories.category_id = categories.category_id
                WHERE categories.category_name = '$category'";
    $sub_result = $conn->query($sub_sql);
    while ($row = $sub_result->fetch_assoc()) {
        $subcategories_list[] = $row['subcategory_name'];
    }
}

// Lapozás beállítása
$limit = 6;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Hirdetések lekérdezése
$sql =
 " SELECT 
        ads.ad_id, 
        ads.title, 
        ads.description, 
        ads.price, 
        ads.creation_date, 
        ads.shipping_method_flag, 
        categories.category_name, 
        subcategories.subcategory_name, 
        brands.name AS brand_name, 
        locations.city_name,
        SUBSTRING_INDEX(GROUP_CONCAT(ads_images.image_url ORDER BY ads_images.image_id), ',', 1) AS image_url
        FROM ads
        RIGHT JOIN ads_images ON ads.ad_id = ads_images.ad_id
        INNER JOIN types ON ads.type_id = types.type_id
        INNER JOIN brands ON types.brand_id = brands.brand_id
        INNER JOIN subcategories ON types.subcategory_id = subcategories.subcategory_id
        INNER JOIN categories ON subcategories.category_id = categories.category_id
        LEFT JOIN locations ON ads.location_id = locations.location_id
    WHERE 1=1" . $search_filter . $category_filter . $subcategory_filter . $price_filter . $shipping_filter . $county_filter . " 
    GROUP BY ads.creation_date DESC
    LIMIT $limit OFFSET $offset";
    
$result = $conn->query($sql);

// Teljes hirdetésszám lekérése a lapozáshoz
$count_sql = "SELECT COUNT(DISTINCT ads.ad_id) as total FROM ads
              RIGHT JOIN ads_images ON ads.ad_id = ads_images.ad_id
              INNER JOIN types ON ads.type_id = types.type_id
              INNER JOIN brands ON types.brand_id = brands.brand_id
              INNER JOIN subcategories ON types.subcategory_id = subcategories.subcategory_id
              INNER JOIN categories ON subcategories.category_id = categories.category_id
              LEFT JOIN locations ON ads.location_id = locations.location_id
              WHERE 1 $search_filter $category_filter $subcategory_filter $price_filter $shipping_filter $county_filter";
$count_result = $conn->query($count_sql);
$total_items = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_items / $limit);

// Vármegyék lekérése az API-ból
$locations = [];
$apiUrl = 'http://localhost/techbazar/RestAPI/api/locations';
$apiResponse = @file_get_contents($apiUrl);
if ($apiResponse !== false) {
    $locations = json_decode($apiResponse, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $locations = [];
    }
}

?>

<script>
function openPopup(pageUrl) {
    document.getElementById("popupFrame").src = pageUrl;
    document.getElementById("popupModal").style.display = "flex";
}

function closePopup() {
    document.getElementById("popupModal").style.display = "none";
    document.getElementById("popupFrame").src = "";
    setTimeout(()=> {location.reload()}, 50);
}

// Szűrők alkalmazása
function applyFilters() {
    const urlParams = new URLSearchParams(window.location.search);
    
    // Keresési kifejezés
    const searchTerm = document.getElementById('search-input').value;
    if (searchTerm) urlParams.set('search', searchTerm);
    else urlParams.delete('search');
    
    // Ár szűrők
    const minPrice = document.getElementById('min-price').value;
    const maxPrice = document.getElementById('max-price').value;
    
    if (minPrice) urlParams.set('min-price', minPrice);
    else urlParams.delete('min-price');
    
    if (maxPrice) urlParams.set('max-price', maxPrice);
    else urlParams.delete('max-price');
    
    // Vármegye szűrő
    const county = document.getElementById('region').value;
    if (county) urlParams.set('county', county);
    else urlParams.delete('county');
    
    // Szállítási mód szűrők
    const shipping = document.getElementById('shipping').checked;
    const personal = document.getElementById('personal').checked;
    
    if (shipping) urlParams.set('shipping', '1');
    else urlParams.delete('shipping');
    
    // Az alapértelmezett oldalra visszaállítás
    urlParams.delete('page');
    
    window.location.search = urlParams.toString();
}

// Keresés gomb eseménykezelő
function handleSearch() {
    const searchTerm = document.getElementById('search-input').value;
    const urlParams = new URLSearchParams(window.location.search);
    
    if (searchTerm) {
        urlParams.set('search', searchTerm);
    } else {
        urlParams.delete('search');
    }
    
    // Töröljük a page paramétert, hogy az első oldalra kerüljünk
    urlParams.delete('page');
    
    window.location.search = urlParams.toString();
}

// Enter billentyű figyelése az ár mezőkben és keresőmezőben
document.addEventListener('DOMContentLoaded', function() {
    const minPriceInput = document.getElementById('min-price');
    const maxPriceInput = document.getElementById('max-price');
    const searchInput = document.getElementById('search-input');
    
    [minPriceInput, maxPriceInput].forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                applyFilters();
            }
        });
    });
    
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
    
    // URL paraméterek beállítása a szűrőkbe
    const urlParams = new URLSearchParams(window.location.search);
    
    if (urlParams.has('search')) {
        document.getElementById('search-input').value = urlParams.get('search');
    }
    
    if (urlParams.has('min-price')) {
        document.getElementById('min-price').value = urlParams.get('min-price');
    }
    
    if (urlParams.has('max-price')) {
        document.getElementById('max-price').value = urlParams.get('max-price');
    }
    
    if (urlParams.has('county')) {
        document.getElementById('region').value = urlParams.get('county');
    }
    
    if (urlParams.has('shipping')) {
        document.getElementById('shipping').checked = true;
    }
    
    if (urlParams.has('personal')) {
        document.getElementById('personal').checked = true;
    }
});

function pageback(page){
    const urlparams  = new URLSearchParams(window.location.search);
    urlparams.set("page", page - 1); 
    window.location.search = urlparams;
}

function pagefront(page){
    const urlparams  = new URLSearchParams(window.location.search);
    urlparams.set("page", page + 1); 
    window.location.search = urlparams;
}

function navigatepage(pagenum){
    const urlparams  = new URLSearchParams(window.location.search);
    urlparams.set("page", pagenum); 
    window.location.search = urlparams;
}
</script>

<!DOCTYPE html>
<html lang="hu"></html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adok-Veszek</title>
    <link rel="stylesheet" href="css/body.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
</head>
<header>
<h1 class="HeaderLogo"><a href="index.php" ><img src="/techbazar/images/logo-removebg-preview.png" alt="Logo"></a></h1>
        <div class="search-bar">
            <input type="text" id="search-input" placeholder="Keresés a hirdetések között..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            <button onclick="handleSearch()">Keresés</button>
        </div>
        <nav class="navbar">
            <?php if (isset($_SESSION['username']) && !empty($_SESSION['username'])): ?>
                <div class="user-info">
                    <a href="/techbazar/profile.php"><span><?php echo htmlspecialchars($_SESSION['username']); ?></span></a>
                    <a href="/techbazar/profile.php"><img class="profilecss" src="/techbazar/<?php echo htmlspecialchars($_SESSION['profilepic']); ?>" alt="Profilkép"></a>
                </div>
                
                <button id="headerbtn" onclick="location.href='/techbazar/logout.php?action=logout'">Kijelentkezés</button>
                <button id="headerbtn" onclick="openPopup('/techbazar/create_listing.php')">Hirdetés feladása</button>
                <button id="headerbtn" onclick="location.href='/techbazar/myads.php'">Hirdetéseim</button>
                <button id="headerbtn" onclick="location.href='Chat/chat.php'">Üzeneteim</button>
            <?php else: ?> 
                <button id="headerbtn" onclick="openPopup('/techbazar/login.php')">Bejelentkezés</button>
            <?php endif; ?>
        </nav>
    </header>
<body>

    <div class="bodystyle">
        <div id="popupModal" class="modal">
            <div class="modal-content">
                <span class="close-btn" onclick="closePopup()">&times;</span>
                <iframe id="popupFrame" name="popupFrame" src=""></iframe>
            </div>
        </div>

        <div class="categories">
            <div class="category"><a href="index.php?category=Hardver">Hardver</a>
                <div class="altcategmenu">
                    <div class="altcategmenu-item">
                        <h3>PC Alkatrészek</h3>
                        <p><a href="index.php?category=Hardver&subcategory=1">Alaplapok</a></p><!-- category_id: 1 -->
                        <p><a href="index.php?category=Hardver&subcategory=2">Processzor</a></p><!-- category_id: 1 -->
                        <p><a href="index.php?category=Hardver&subcategory=4">Processzor Hűtés</a></p><!-- category_id: 1 -->
                        <p><a href="index.php?category=Hardver&subcategory=3">Memória</a></p><!-- category_id: 1 -->
                        <p><a href="index.php?category=Hardver&subcategory=7">Videokártya</a></p><!-- category_id: 1 -->
                        <p><a href="index.php?category=Hardver&subcategory=6">Táp</a></p><!-- category_id: 1 -->
                        <p><a href="index.php?category=Hardver&subcategory=5">Ház</a></p><!-- category_id: 1 -->
                    </div>
                    <div class="altcategmenu-item">
                        <h3>Perifériák</h3>
                        <p><a href="index.php?category=Hardver&subcategory=9">Nyomtató, szkenner</a><!-- category_id: 1 --></p>
                        <p><a href="index.php?category=Hardver&subcategory=10">Egyéb hardverek</a><!-- category_id: 1 --></p>
                    </div>
                    <div class="altcategmenu-item">
                        <h3>Tárolás</h3>
                        <p><a href="index.php?category=Hardver&subcategory=11">Belső, Külső meghajtók</a><!-- category_id: 1 --></p>
                    </div>
                </div>
            </div>

            <div class="category"><a href="index.php?category=Számítógép, Konzol">Számítógép, Konzol</a>
                <div class="altcategmenu">
                    <div class="altcategmenu-item">
                        <h3>Asztali Gépek</h3>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=12">Asztali gép</a><!-- category_id: 2 --></p>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=13">Apple Mac, iMac</a><!-- category_id: 2 --></p>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=14">Mini PC</a><!-- category_id: 2 --></p>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=15">Játékvezérlő, számítógép</a><!-- category_id: 2 --></p>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=16">VR</a> <!-- category_id: 2 -->
                        </p>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=17">Billentyűzet, egér/pad</a><!-- category_id: 2 --></p>
                    </div>
                    <div class="altcategmenu-item">
                        <h3>Játékkonzolok</h3>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=18">PlayStation konzolok</a><!-- category_id: 2 --></p>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=19">Xbox konzolok</a><!-- category_id: 2 --></p>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=20">Nintendo konzolok</a><!-- category_id: 2 --></p>
                        <p><a href="index.php?category=Számítógép, Konzol&subcategory=21">Egyéb konzolok</a><!-- category_id: 2 --></p>
                    </div>
                </div>
            </div>

            <div class="category"><a href="index.php?category=Laptop">Laptop</a>
                <div class="altcategmenu">
                    <div class="altcategmenu-item">
                        <h3>Notebookok</h3>
                        <p><a href="index.php?category=Laptop&subcategory=22">Apple laptopok</a> <!-- category_id: 4 --></p>
                        <p><a href="index.php?category=Laptop&subcategory=23">PC laptopok</a> <!-- category_id: 4 --></p>
                        <p><a href="index.php?category=Laptop&subcategory=24">Szerviz, Boltok</a><!-- category_id: 4 --></p>
                    </div>
                </div>
            </div>

            <div class="category"><a href="index.php?category=Telefon, Tablet">Okoseszközök</a>
                <div class="altcategmenu">
                    <div class="altcategmenu-item">
                        <h3>Okostelefonok</h3>
                        <p><a href="index.php?category=Telefon, Tablet&subcategory=25">Telefonok</a></p>
                    </div>
                    <div class="altcategmenu-item">
                        <h3>Tabletek</h3>
                        <p><a href="index.php?category=Telefon, Tablet&subcategory=27">Tabletek</a><!-- category_id: 4 --></p>
                        <p><a href="index.php?category=Telefon, Tablet&subcategory=29">Tartozék, alkatrész</a><!-- category_id: 4 --></p>
                    </div>
                    <div class="altcategmenu-item">
                        <h3>Boltok/Szervizek</h3>
                        <p><a href="index.php?category=Telefon, Tablet&subcategory=24">Boltok és Szervizek</a></p>
                    </div>
                </div>
            </div>

            <div class="category"><a href="index.php?category=TV, Hangtechnika">TV, Hangtechnika</a>
                <div class="altcategmenu">
                    <div class="altcategmenu-item">
                        <h3>TV-k</h3>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=30">Televízió</a><!-- category_id: 5 --></p>
                    </div>
                    <div class="altcategmenu-item">
                        <h3>Hangeszközök</h3>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=32">Erősítő, hangfal</a><!-- category_id: 5 --></p>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=33">Fejhallgató, fülhallgató</a><!-- category_id: 5 --></p>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=34">Mikrofon</a><!-- category_id: 5 --></p>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=35">Medialejátszó</a><!-- category_id: 5 --></p>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=36">DAC</a> <!-- category_id: 5 --></p>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=37">Kábelek</a><!-- category_id: 5 --></p>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=38">DJ, stúdó kiegészítők</a><!-- category_id: 5 --></p>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=39">Autó HIFI</a><!-- category_id: 5 --></p>
                    </div>
                    <div class="altcategmenu-item">
                        <h3>Házimozi</h3>
                        <p><a href="index.php?category=TV, Hangtechnika&subcategory=31">Projektor</a><!-- category_id: 5 --></p>
                    </div>
                </div>
            </div>

            <div class="category"><a href="index.php?category=Egyéb">Egyéb</a>
                <div class="altcategmenu">
                    <div class="altcategmenu-item">
                        <p><a href="index.php?category=Egyéb&subcategory=41">Kamerák</a> <!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=42">Dronok</a> <!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=43">Szoftverek</a> <!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=44">Otthon, háztartás</a><!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=45">Ruházat, órák</a> <!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=46">Sport</a> <!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=47">Járművek, rollerek<br> biciklik</a><!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=48">Táskák, Lakások</a> <!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=49">Egyéb</a> <!-- category_id: 6 --></p>
                        <p><a href="index.php?category=Egyéb&subcategory=50">Ingyen elvihető</a> <!-- category_id: 6 --></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="filter-box">
            <label for="min-price">Min Ár:</label>
            <input type="text" id="min-price" placeholder="Minimális ár">
            <label for="max-price">Max Ár:</label>
            <input type="text" id="max-price" placeholder="Maximális ár">
            <label for="region">Vármegye:</label>
            <select id="region" name="region">
                <option value="">Összes vármegye</option>
                <?php foreach ($locations as $location): ?>
                    <option value="<?= htmlspecialchars($location['city_name']) ?>">
                        <?= htmlspecialchars($location['city_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        
        </div>


        <div class="DeliveryOptions">
            <label><input type="checkbox" id="shipping" name="shipping"> Csomagküldés</label>
            <label><input type="checkbox" id="personal" name="personal"> Személyes</label>
        </div>
        <button class="Apply-filter-btn" id="headerbtn" onclick="applyFilters()">Szűrés</button>
        <div class="items">
            <?php
            if ($result->num_rows > 0) {
                while ($ad = $result->fetch_assoc()) {
                    $creationDate = $ad['creation_date'];
                    $currentDate = new DateTime();
                    $creationDateTime = new DateTime($creationDate);
                    $interval = $currentDate->diff($creationDateTime);

                    if ($interval->y > 0) {
                        $timeString = $interval->y . ' évvel ezelőtt';
                    } elseif ($interval->m > 0) {
                        $timeString = $interval->m . ' hónappal ezelőtt';
                    } elseif ($interval->d >= 7) {
                        $weeks = floor($interval->d / 7);
                        $timeString = $weeks . ' héttel ezelőtt';
                    } elseif ($interval->d > 0) {
                        $timeString = $interval->d . ' nappal ezelőtt';
                    } elseif ($interval->h > 0) {
                        $timeString = $interval->h . ' órával ezelőtt';
                    } elseif ($interval->i > 0) {
                        $timeString = $interval->i . ' perccel ezelőtt';
                    } else {
                        $timeString = $interval->s . ' másodperccel ezelőtt';
                    }

                    echo '<a href="ad_details.php?ad_id=' . $ad['ad_id'] . '" class="btn" style="text-decoration: none;">
                        <div class="item">
                            <img src="' . htmlspecialchars($ad['image_url']) . '" alt="Hirdetés kép">
                            <div class="details">
                                <h3 class="cardh3title">' . htmlspecialchars($ad['title']) . '</h3> 
                                <hr style="text-decoration: underline; font-style: none; background-color: black !important; color: black !important ;">

                                <!--
                                <p>Kategória: ' . htmlspecialchars($ad['category_name']) . '</p>
                                <p>Alkategória: ' . htmlspecialchars($ad['subcategory_name']) . '</p>
                                -->
                                
                                <p>Márka: ' . htmlspecialchars($ad['brand_name']) . '</p>
                                <p class="descriptionp">Leírás: ' . nl2br(htmlspecialchars(strip_tags(($ad['description'])))) . '</p>
                                <p class="price">' . number_format($ad['price'], 0, '', ' ') . ' Ft</p>
                                <div class="szallitas-miota">
                                    <p class="shipping-method">Szállítás: ' . ($ad['shipping_method_flag'] ? 'Csomagküldés' : 'Személyes átvétel') . '</p>
                                    <p class="time-ago">' . $timeString . '</p>
                                </div>
                        </div>
                    </div>
                    </a>';
                }
            } else {
                echo '<p class="nincshirdetes">' . (isset($_GET['search']) ? 'Nincs találat a keresési feltételeknek megfelelő hirdetés.' : 'Nincs még egyetlen hirdetés sem.') . '</p>';
            }
            ?>
        </div>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <button onclick="pageback(<?= $page ?>)">Előző</button>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <button onclick="navigatepage(<?= $i ?>)" <?= $i === $page ? 'class="active" id="selectedpage"' : '' ?>> <?= $i ?> </button>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <button onclick="pagefront(<?= $page ?>)">Következő</button>
            <?php endif; ?>
        </div>
    </div>
    <?php require "footer.php"; ?>
</body>

</html>

<?php
$conn->close(); // Az adatbázis kapcsolat lezárása
?>