<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ujhasznal2";

// Csatlakozás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Bejelentkezési űrlap kezelése
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $passwordInput = $_POST['password'];

    // Ellenőrizzük a felhasználót az adatbázisban (most már az is_admin mezőt is lekérjük)
    $stmt = $conn->prepare("SELECT user_id, username, email, password, profilepic, banned, ban_reason, is_admin FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Ellenőrizzük, hogy a felhasználó kitiltva van-e
        if ($user['banned'] == 1) {
            echo "<script>
                    alert('Ki vagy tiltva!\\n\\nIndok: " . addslashes($user['ban_reason']) . "');
                    window.close();
                  </script>";
            exit();
        } else {
            // Ellenőrizzük a jelszót
            if (password_verify($passwordInput, $user['password'])) {
                // Adatok tárolása a munkamenetben (most már az admin státuszt is elmentjük)
                $_SESSION['username'] = $user['username'];
                $_SESSION['profilepic'] = $user['profilepic'];
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['is_admin'] = (bool)$user['is_admin']; // Admin státusz elmentése

                // Átirányítás a főoldalra
                header("Location: index.php");
                exit();
            } else {
                echo "<script>alert('Helytelen jelszó!');</script>";
            }
        }
    } else {
        echo "<script>alert('Nem található ilyen e-mail cím!');</script>";
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bejelentkezés</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="css/loginstyle.css">
</head>
<body>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const emailInput = document.querySelector("input[name='email']");
        const passwordInput = document.querySelector("input[name='password']");
        const loginBtn = document.getElementById("loginbtn");

        function checkInputs() {
            loginBtn.disabled = !(emailInput.value.trim() && passwordInput.value.trim());
        }

        emailInput.addEventListener("input", checkInputs);
        passwordInput.addEventListener("input", checkInputs);

        checkInputs(); // Ellenőrizzük az oldal betöltésekor
    });
</script>

<img src="images/logo-removebg-preview.png" alt="logó">
<h1>Bejelentkezés</h1>
<form method="POST" action="login.php">
    <label>Email:</label>
    <input type="email" name="email" required>
    <label>Jelszó:</label>
    <input type="password" name="password" required>
    <label for="">Esetleg még nincs fiókod? <a href="register.php">Regisztrálj itt!</a></label>
    <button type="submit" id="loginbtn" id="submitBtn"onclick="window.parent.closePopup()">Bejelentkezés</button>
</form>

<!-- Bootstrap Modal -->
<div class="modal fade" id="banModal" tabindex="-1" aria-labelledby="banModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="banModalLabel">Ki vagy tiltva!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Kitiltás oka: <?= $ban_reason ?? 'Nincs indoklás megadva.' ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Bezárás</button>
            </div>
        </div>
    </div>
</div>

</body>
</html>