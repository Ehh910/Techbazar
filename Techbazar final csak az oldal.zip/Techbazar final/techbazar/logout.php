<?php
// Ellenőrizzük, hogy a munkamenet elindult-e
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Start the session to access session variables
}

// Kijelentkezés kezelése
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    // Munkamenet változók törlése
    $_SESSION = [];

    // Munkamenet lezárása
    session_destroy();

    // Átirányítás az index oldalra
    header("Location: /techbazar/index.php");
    exit();
}