<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$usernameDB = "root";
$password = "";
$dbname = "ujhasznal2";

$conn = new mysqli($servername, $usernameDB, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Alapértékek beállítása
$imageUrls = [];

// Hirdetés szerkesztése
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_ad'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $ad_id = $_POST['ad_id'];

    $updateStmt = $conn->prepare("UPDATE ads SET title = ?, description = ?, price = ? WHERE ad_id = ? AND user_id = ?");
    $updateStmt->bind_param("sssii", $title, $description, $price, $ad_id, $_SESSION['user_id']);

    if ($updateStmt->execute()) {
        $_SESSION['success'] = "Hirdetés sikeresen frissítve!";
    } else {
        $_SESSION['error'] = "Hiba történt a frissítés során! " . $updateStmt->error;
    }
}

// Hirdetés törlése
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_ad'])) {
    $ad_id = $_POST['ad_id'];
    
    // Először töröljük a hirdetéshez tartozó képeket
    $deleteImagesStmt = $conn->prepare("DELETE FROM ads_images WHERE ad_id = ?");
    $deleteImagesStmt->bind_param("i", $ad_id);
    $deleteImagesStmt->execute();
    $deleteImagesStmt->close();
    
    // Majd töröljük magát a hirdetést
    $deleteAdStmt = $conn->prepare("DELETE FROM ads WHERE ad_id = ? AND user_id = ?");
    $deleteAdStmt->bind_param("ii", $ad_id, $_SESSION['user_id']);
    
    if ($deleteAdStmt->execute()) {
        $_SESSION['success'] = "Hirdetés sikeresen törölve!";
        // Itt adjuk meg a teljes elérési utat
        header("Location: " . (isset($_SERVER['HTTPS']) ? "https://" : "http://") . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/" . basename($_SERVER['PHP_SELF']));
        exit();
    } else {
        $_SESSION['error'] = "Hiba történt a törlés során! " . $deleteAdStmt->error;
    }
    $deleteAdStmt->close();
}

// Felhasználó hirdetéseinek lekérdezése
$user_id = $_SESSION['user_id'];
$adsQuery = $conn->prepare("SELECT ads.*, types.name AS type_name, locations.city_name, 
           COALESCE(GROUP_CONCAT(ads_images.image_url SEPARATOR ','), '') AS image_urls 
    FROM ads 
    LEFT JOIN ads_images ON ads.ad_id = ads_images.ad_id 
    JOIN types ON ads.type_id = types.type_id 
    JOIN locations ON ads.location_id = locations.location_id 
    WHERE ads.user_id = ? 
    GROUP BY ads.ad_id 
    ORDER BY ads.creation_date DESC");
$adsQuery->bind_param("i", $user_id);
$adsQuery->execute();
$adsResult = $adsQuery->get_result();
$ads = $adsResult->fetch_all(MYSQLI_ASSOC);

// Ha nincs hirdetés, legyen üres tömb
if ($ads === null) {
    $ads = [];
}
?>

<?php require "head.php"; ?>
<link rel="stylesheet" href="css/ad_details.css">
<link href="https://cdn.jsdelivr.net/npm/quill@2.0.3/dist/quill.snow.css" rel="stylesheet" />

<script>
    function formatText(command) {
        document.execCommand(command, false, null);
    }

    function insertLink() {
        let url = prompt("Add meg a linket:");
        if (url) {
            document.execCommand("createLink", false, url);
        }
    }

    // Szöveg beillesztése a textarea mezőbe mentés előtt
    function saveContent(adId) {
        // Get the HTML content from the Quill editor
        const editorContent = quills[adId].root.innerHTML;
        document.getElementById("hiddenTextarea-" + adId).value = editorContent;
    }

    function confirmDelete(adId) {
    if (confirm("Biztosan törölni szeretnéd ezt a hirdetést? A művelet nem visszavonható!")) {
        // Létrehozunk egy láthatatlan formot a törléshez
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = window.location.href; // Az aktuális oldalra küldjük
        
        const inputAdId = document.createElement('input');
        inputAdId.type = 'hidden';
        inputAdId.name = 'ad_id';
        inputAdId.value = adId;
        
        const inputDelete = document.createElement('input');
        inputDelete.type = 'hidden';
        inputDelete.name = 'delete_ad';
        inputDelete.value = '1';
        
        form.appendChild(inputAdId);
        form.appendChild(inputDelete);
        document.body.appendChild(form);
        form.submit();
    }
}
</script>

<!-- Popup Modal -->
<div id="popupModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close-btn" onclick="closePopup()">&times;</span>
        <iframe id="popupFrame" name="popupFrame" src=""></iframe>
    </div>
</div>

<div class="hirdetescontainer">
    <?php if (empty($ads)): ?>
        <p>Nem találtunk hirdetéseket a profilodon.</p>
    <?php else: ?>
        <?php foreach ($ads as $ad): ?>
        <div class="ad_card_details">
            <h3><?= htmlspecialchars($ad['title']) ?></h3>
            <p>Ár: <?= number_format($ad['price'], 0, ',', ' ') ?> Ft</p>
            <p>Helyszín: <?= htmlspecialchars($ad['city_name']) ?></p>

            <?php 
            $imageUrls = !empty($ad['image_urls']) ? explode(',', $ad['image_urls']) : []; 
            $carouselId = "carousel-" . $ad['ad_id']; // Egyedi azonosító a carouselnek
            ?>
            <div class="adimgbckgrd">
                <div class="image-carousel" id="<?= $carouselId ?>">
                    <div class="adimg">
                    <?php if (!empty($imageUrls)): ?>
                        <?php foreach ($imageUrls as $index => $imageUrl): ?>
                            <img src="<?= htmlspecialchars($imageUrl); ?>" class="carousel-image <?= $index === 0 ? 'active' : ''; ?>" alt="Hirdetés kép <?= $index + 1; ?>">
                        <?php endforeach; ?>
                        <button class="carousel-button prev" onclick="prevImage('<?= $carouselId ?>')">❮</button>
                        <button class="carousel-button next" onclick="nextImage('<?= $carouselId ?>')">❯</button>
                    <?php else: ?>
                        <p>Nincs kép feltöltve.</p>
                    <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Szerkesztő form -->
            <form method="POST" class="editadform">
                <input type="hidden" name="ad_id" value="<?= $ad['ad_id'] ?>">
                <label for="title">Hirdetés címe: </label>
                <input id="titleedit" oninput="validateInputtitle(this)" type="text" name="title" value="<?= htmlspecialchars($ad['title']) ?>" required>
                
                <label for="price">Hirdetéshez tartozó ár: </label>
                <input id="priceedit" min="0" max="999999999" type="number" name="price" value="<?= $ad['price'] ?>" required>
                
                <label for="description">Hirdetés leírása: </label>
                <!-- Quill editor -->
                <div class="descriptioneditor">
                    <div id="editor-<?= $ad['ad_id'] ?>" style="height: 200px;">
                        <?= htmlspecialchars_decode($ad['description']); ?>
                    </div>
                </div>
                <input type="hidden" name="description" id="hiddenTextarea-<?= $ad['ad_id'] ?>">

                <div class="button-group">
                    <button type="submit" name="edit_ad" class="mentesgomb" id="headerbtn" onclick="saveContent('<?= $ad['ad_id'] ?>')">MENTÉS</button>
                    <button type="button" class="torlesgomb" id="headerbtn" onclick="confirmDelete('<?= $ad['ad_id'] ?>')">TÖRLÉS</button>
                </div>
            </form>

        </div> <!-- Ad-card zárása -->
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include "footer.php"; ?>

<?php
if (isset($stmt)) {
    $stmt->close();
}
?>

<!-- Include the Quill library -->
<script src="https://cdn.jsdelivr.net/npm/quill@2.0.3/dist/quill.js"></script>

<script>
    const quills = {};

    // Quill editor inicializálása
    <?php foreach ($ads as $ad): ?>
        quills[<?= $ad['ad_id'] ?>] = new Quill('#editor-<?= $ad['ad_id'] ?>', {
            theme: 'snow'
        });
        // Set the initial content of the Quill editor as plain text
        quills[<?= $ad['ad_id'] ?>].setText(`<?= addslashes(strip_tags($ad['description'])) ?>`);
    <?php endforeach; ?>

    function saveContent(adId) {
        // A Quill editor tartalmának elmentése a rejtett textarea-ba
        const editorContent = quills[adId].root.innerHTML;
        document.getElementById("hiddenTextarea-" + adId).value = editorContent;
    }

    function validateDescription(editorDiv, hiddenTextareaId) {
        const maxWordLength = 20;
        const words = editorDiv.innerText.split(/\s+/); // Get text from contenteditable div

        if (words.some(word => word.length > maxWordLength)) {
            alert("Egyedüli szavak hossza nem lehet több 20 karakternél");

            // Trim words longer than maxWordLength
            editorDiv.innerText = words.map(word => 
                word.length > maxWordLength ? word.slice(0, maxWordLength) : word
            ).join(" ");

            // Place cursor at the end after modification
            placeCursorAtEnd(editorDiv);
            // Remove formatting from the editor
            removeTextFormatting(input);
        }

        // Sync the cleaned text back to the hidden textarea
        document.getElementById(hiddenTextareaId).value = editorDiv.innerHTML;
    }

    // **Function to place cursor at the end after reset**
    function placeCursorAtEnd(element) {
        const range = document.createRange();
        const selection = window.getSelection();
        range.selectNodeContents(element);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
    }

    const quill = new Quill('#editor', {
        theme: 'snow'
    });

    function validateInputtitle(input) {
        const words = input.value.split(/\s+/); // Split text into words
        const maxWordLength = 20;
        const maxLength = 60;
        
        if (input.value.length > maxLength) {
            alert("A cím hossza nem lehet több mint 60 karakter");
            input.value = input.value.slice(0, maxLength); // Trim to max length
        }

        if (words.some(word => word.length > maxWordLength)) {
            alert("Egyedüli szavak hossza nem lehet több 20 karakternél");
            input.value = input.value.slice(0, -1); // Remove last character
        }
    }

    function placeCursorAtEnd(element) {
        const range = document.createRange();
        const selection = window.getSelection();
        range.selectNodeContents(element);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
    }

    function openPopup(pageUrl) {
        const popupFrame = document.getElementById("popupFrame");
        const popupModal = document.getElementById("popupModal");

        if (popupFrame && popupModal) {
            popupFrame.src = pageUrl;
            popupModal.style.display = "flex";
        }
    }

    function closePopup() {
        const popupFrame = document.getElementById("popupFrame");
        const popupModal = document.getElementById("popupModal");

        if (popupFrame && popupModal) {
            popupModal.style.display = "none";
            popupFrame.src = ""; // Clear the iframe content
            setTimeout(() => {
                location.reload(); // Reload the page to reflect changes
            }, 50);
        }
    }

    let currentImageIndex = 0;
    const images = document.querySelectorAll('.carousel-image');

    function showImage(index) {
        images.forEach((img, i) => {
            img.classList.remove('active');
            if (i === index) {
                img.classList.add('active');
            }
        });
    }

    function prevImage(carouselId) {
        const carousel = document.getElementById(carouselId);
        if (!carousel) return;

        const images = carousel.querySelectorAll('.carousel-image');
        let activeIndex = Array.from(images).findIndex(img => img.classList.contains('active'));

        images[activeIndex].classList.remove('active');
        activeIndex = (activeIndex > 0) ? activeIndex - 1 : images.length - 1;
        images[activeIndex].classList.add('active');
    }

    function nextImage(carouselId) {
        const carousel = document.getElementById(carouselId);
        if (!carousel) return;

        const images = carousel.querySelectorAll('.carousel-image');
        let activeIndex = Array.from(images).findIndex(img => img.classList.contains('active'));

        images[activeIndex].classList.remove('active');
        activeIndex = (activeIndex < images.length - 1) ? activeIndex + 1 : 0;
        images[activeIndex].classList.add('active');
    }
</script>