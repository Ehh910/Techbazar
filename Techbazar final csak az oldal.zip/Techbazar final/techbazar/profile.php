<?php
session_start();

require "connect.php";

// Determine which user's profile to display
$view_user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : $_SESSION['user_id'];

// Felhasználó adatainak lekérdezése
$sql = "SELECT username, profilepic, registration_date, last_login FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $view_user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "Felhasználó nem található.";
    exit();
}
?>

<?php require "head.php"; ?>
<link rel="stylesheet" href="css/styleprofile.css">

<div id="popupModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closePopup()">&times;</span>
        <iframe id="popupFrame" name="popupFrame" src=""></iframe>
    </div>
</div>

<main>
    <div class="profile-container">
        <!-- Sidebar -->
        <div class="profile-sidebar">
            <div class="profile-header">
                <?php if ($user['profilepic']): ?>
                    <img src="<?php echo htmlspecialchars($user['profilepic']); ?>" alt="Profilkép" class="profile-image">
                <?php else: ?>
                    <div class="profile-image-placeholder" style="width:120px;height:120px;background:#ddd;border-radius:50%;margin:0 auto;"></div>
                <?php endif; ?>
                <h2><?php echo htmlspecialchars($user['username']); ?></h2>
            </div>
            
            <div class="profile-info">
                <h3 class="section-title">Profil adatok</h3>
                <p><strong>Regisztráció dátuma:</strong> <?php echo htmlspecialchars($user['registration_date']); ?></p>
                <?php if ($user['last_login']): ?>
                    <p><strong>Utolsó bejelentkezés:</strong> <?php echo htmlspecialchars($user['last_login']); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Content -->
        <div class="profile-content">
            <h2 class="section-title">Aktív hirdetéseim</h2>
            
            <?php
            // Hirdetések lekérdezése
            $items_per_page = 2;
            $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            if ($current_page < 1) $current_page = 1;
            $offset = ($current_page - 1) * $items_per_page;

            $count_sql = "SELECT COUNT(*) as total FROM ads WHERE user_id = ?";
            $count_stmt = $conn->prepare($count_sql);
            $count_stmt->bind_param("i", $view_user_id);
            $count_stmt->execute();
            $count_result = $count_stmt->get_result();
            $total_items = $count_result->fetch_assoc()['total'];
            $count_stmt->close();

            $total_pages = ceil($total_items / $items_per_page);

            $listings_sql = "SELECT ads.*, locations.city_name, 
                            (SELECT GROUP_CONCAT(image_url) FROM ads_images WHERE ad_id = ads.ad_id) as images
                            FROM ads 
                            LEFT JOIN locations ON ads.location_id = locations.location_id
                            WHERE ads.user_id = ?
                            LIMIT ? OFFSET ?";
            $listings_stmt = $conn->prepare($listings_sql);
            $listings_stmt->bind_param("iii", $view_user_id, $items_per_page, $offset);
            $listings_stmt->execute();
            $listings_result = $listings_stmt->get_result();

            if ($listings_result->num_rows > 0) {
                while ($listing = $listings_result->fetch_assoc()) {
                    echo '<div class="listing-item" onclick="window.location.href=\'ad_details.php?ad_id=' . $listing['ad_id'] . '\'">';
                    
                    if (!empty($listing['images'])) {
                        $images = explode(',', $listing['images']);
                        echo '<div class="listing-images">';
                        echo '<img src="' . htmlspecialchars($images[0]) . '" alt="Hirdetés kép" class="listing-image">';
                        echo '</div>';
                    } else {
                        echo '<div class="listing-images">';
                        echo '<img src="images/no-image.jpg" alt="Nincs kép" class="listing-image">';
                        echo '</div>';
                    }
                    
                    echo '<h4>' . htmlspecialchars(strip_tags(($listing['title']))) . '</h4>';
                    echo '<p class="listing-description">' . htmlspecialchars(strip_tags(($listing['description']))) . '</p>';
                    
                    echo '<div class="listing-meta">';
                    echo '<span class="price-tag">' . number_format($listing['price'], 0, ',', ' ') . ' Ft</span>';
                    echo '<span class="location-tag">' . htmlspecialchars($listing['city_name']) . '</span>';
                    echo '<span class="date-tag">' . date('Y.m.d', strtotime($listing['creation_date'])) . '</span>';
                    echo '</div>';
                    
                    echo '</div>';
                }

                echo '<div class="pagination">';
                if ($current_page > 1) {
                    echo '<a href="?user_id=' . $view_user_id . '&page=' . ($current_page - 1) . '" class="page-link">&laquo; Előző</a>';
                }

                for ($i = 1; $i <= $total_pages; $i++) {
                    if ($i == $current_page) {
                        echo '<span class="page-link current">' . $i . '</span>';
                    } else {
                        echo '<a href="?user_id=' . $view_user_id . '&page=' . $i . '" class="page-link">' . $i . '</a>';
                    }
                }

                if ($current_page < $total_pages) {
                    echo '<a href="?user_id=' . $view_user_id . '&page=' . ($current_page + 1) . '" class="page-link">Következő &raquo;</a>';
                }
                echo '</div>';
            } else {
                echo '<p>Nincs aktív hirdetés.</p>';
            }

            $listings_stmt->close();
            ?>
        </div>
    </div>
</main>

<?php require "footer.php"; ?>

<script>
function openPopup(pageUrl) {
    document.getElementById("popupFrame").src = pageUrl;
    document.getElementById("popupModal").style.display = "flex";
}

function closePopup() {
    document.getElementById("popupModal").style.display = "none";
    document.getElementById("popupFrame").src = "";
    setTimeout(()=> {location.reload()}, 50);
}
</script>

</body>
</html>

<?php
$conn->close();
?>