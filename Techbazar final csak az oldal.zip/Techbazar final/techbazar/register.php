<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/registerstyle.css">
    <title>Regisztráció</title>
</head>
<body>
<img src="/techbazar/images/logo-removebg-preview.png" alt="">

<form action="register.php" method="POST">
    <label for="username">Felhasználónév:</label>
    <input type="text" id="username" name="username" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="password">Jelszó:</label>
    <input type="password" id="password" name="password" required>

    <label>Válassz alapértelmezett profilképet:</label>
    <div id="default-pictures">
        <?php
        $defaultPicturesDir = "default_profiles/";
        $defaultPictures = array_diff(scandir($defaultPicturesDir), array('.', '..'));
        foreach ($defaultPictures as $picture) {
            echo "<label>";
            echo "<input type='radio' name='default_profilepic' value='$defaultPicturesDir$picture' required>";
            echo "<img src='$defaultPicturesDir$picture' alt='default picture' id='default_pictures'>";
            echo "</label>";
        }
        ?>
    </div>
    
<label for="">Már van fiókod? <a href="login.php">Jelentkezz be itt!</a></label>
    <button type="submit" onclick="openPage('login.php')">Regisztrálás</button>
</form>

<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ujhasznal2";

// Csatlakozás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Regisztrációs űrlap adatok
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // A felhasználói adatok
    $username = $_POST['username'];
    $email = $_POST['email'];
    $passwordInput = $_POST["password"];

    $password = password_hash($passwordInput, PASSWORD_BCRYPT); // Jelszó titkosítása

    // Profilkép beállítása
    if (!empty($_POST['default_profilepic'])) {
        // Ha alapértelmezett profilképet választott
        $target_file = $_POST['default_profilepic'];
    } else {
        echo "Nem választottál profilképet.";
        exit();
    }

    // Ellenőrizzük, hogy létezik-e már a felhasználó e-mail címe
    $email_check_query = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($email_check_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Ez az e-mail cím már használatban van!";
        exit();
    }

    // Felhasználó hozzáadása az adatbázishoz
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, profilepic) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $email, $password, $target_file);

    if ($stmt->execute()) {
        echo "Sikeresen regisztráltál! Kérlek jelentkezz be!";
    } else {
        echo "Hiba: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>


</body>
</html>
